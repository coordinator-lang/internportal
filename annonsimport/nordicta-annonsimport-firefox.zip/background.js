// Nordicta Annonsimport – service worker (MV3)
// On toolbar-click: harvest the CURRENT listing page (rendered DOM + every photo URL) inside
// the user's own browser (no server fetch → no Qasa/Airbnb 429), stash it, and open the review
// page. The review page sends the HTML to extract-listing and drives the import.

// Runs in the page context via chrome.scripting — must be fully self-contained (no outer refs).
function harvestPage() {
  const html = document.documentElement.outerHTML;
  const pageUrl = location.href;
  // Airbnb-annonsens id star i URL:en (/rooms/<id>) OCH i varje foto-URL (Hosting-<id>/).
  // Sektioner som "Fler boenden i narheten" visar ANDRA annonsers foton - de bar ett annat
  // id och far aldrig folja med. Verifierat: alla 29 foto-URL:er pa /rooms/43473343 bar det id:t.
  const roomId = (function () {
    const p = location.pathname;
    const at = p.indexOf("/rooms/");
    if (at < 0) return "";
    const rest = p.slice(at + 7);
    let out = "";
    for (let c = 0; c < rest.length; c++) {
      const ch = rest.charAt(c);
      if (ch >= "0" && ch <= "9") out += ch; else break;
    }
    return out;
  })();
  // Vissa sajter bakar in bild-URL:er i JSON dar snedstrecken ar escapade. Av-escapa EN gang
  // har, sa slipper alla regexar nedan hantera det (och slipper dubbla backslash).
  const BSLASH = String.fromCharCode(92);
  const flat = html.split(BSLASH + '/').join('/');

  const abs = (u) => { try { return new URL(u, location.href).href; } catch (e) { return null; } };

  // Qasa levererar samma foto via en bildproxy i flera transformer. Normalisera till
  // fullstorleks-varianten redan har, annars slipper bada igenom dedupen.
  const canon = (u) => {
    const t = String(u);
    const p = t.indexOf("img.qasa.se/unsafe/");
    if (p < 0) return t;
    const k = t.indexOf("http", p + "img.qasa.se/unsafe/".length);
    if (k < 0) return t;
    return "https://img.qasa.se/unsafe/adaptive-fit-in/1200x1200/" + t.slice(k);
  };

  // Aldrig annonsfoton: logotyper, ikoner, kartor, annonser - och appens EGNA statiska filer
  // (Next.js /_next/static/, /static/media/). Verifierat pa homeq.se, dar en partnerlogga
  // annars blev enda "fotot", och pa wg-gesucht (partnerannonser).
  const BAD = /(sprite|logo|favicon|\bicon|avatar|profile-?pic|placeholder|banner|advert|\bads?\b|pixel|tracking|beacon|\bmaps?\b|\/geo\/|_next\/static|\/static\/media\/|badge|\bflag\b|watermark|kooperation|partner|sponsor|affiliate)/i;

  // Identitet for dedup: strippa storleks-tokens OCH rena siffer-mappar, sa att
  // /1440/apartment_images/X.jpg och /apartment_images/X.jpg raknas som samma foto.
  const idOf = (u) => String(u).split('?')[0]
    .replace(/\/\d{2,4}x\d{2,4}\//g, '/')
    .replace(/\/\d{2,4}\//g, '/')
    .replace(/[_-]\d{2,4}x\d{2,4}(?=\.[a-z]{3,4}$)/i, '')
    .replace(/[_-](small|medium|large|thumb|thumbnail|orig|original|xs|sm|md|lg|xl)(?=\.[a-z]{3,4}$)/i, '')
    .toLowerCase();

  const bestFromSrcset = (ss) => {
    if (!ss) return null;
    let best = null, bestW = -1;
    String(ss).split(',').forEach((part) => {
      const bits = part.trim().split(/\s+/);
      if (!bits[0]) return;
      const m = (bits[1] || '').match(/^(\d+)w$/);
      const w = m ? parseInt(m[1], 10) : 0;
      if (w > bestW) { bestW = w; best = bits[0]; }
    });
    return best;
  };

  const inChrome = (el) => {
    try {
      return !!el.closest('header, nav, [role="banner"], [role="navigation"], [class*="avatar"], [class*="Avatar"], [class*="logo"], [class*="Logo"]');
    } catch (e) { return false; }
    // NOTE: aldrig `button` har - Qasa lindar hela galleriet i en klickbar knapp.
  };

  const picked = [];
  const denyId = {};
  const seenId = {};

  // w/h = hur stor bilden ar i layouten, nw/nh = sjalva bildfilens storlek.
  const consider = (rawUrl, el, w, h, nw, nh) => {
    const u = canon(abs(rawUrl) || '');
    if (!u || !/^https?:/i.test(u)) return;
    if (!/\.(jpe?g|png|webp|avif)(\?|$)/i.test(u) && !/\/(image|photo|img|media)/i.test(u)) return;
    const id = idOf(u);
    const small = w > 0 && h > 0 && w <= 80 && h <= 80;
    if (small || BAD.test(u) || (el && inChrome(el))) { denyId[id] = 1; return; }
    // Foto fran en ANNAN Airbnb-annons (t.ex. "Fler boenden i narheten").
    if (roomId && u.indexOf("muscache.com") > 0 && u.indexOf("Hosting-") > 0
        && u.indexOf("Hosting-" + roomId + "/") < 0) { denyId[id] = 1; return; }
    // Utlagd i fotostorlek ELLER en stor bildfil som bara inte ar utlagd just nu. Det andra
    // kravs for karuseller/slides (homeq.se renderar dolda slides med bredd 0).
    const renderedBig = w >= 140 && h >= 100;
    const fileBig = nw >= 500 && nh >= 350;
    if (renderedBig || fileBig) {
      if (!seenId[id]) { seenId[id] = 1; picked.push({ url: u, id: id }); }
    }
  };

  document.querySelectorAll('img').forEach((im) => {
    const r = im.getBoundingClientRect();
    const cand = bestFromSrcset(im.getAttribute('srcset')) || im.currentSrc || im.getAttribute('src')
      || im.getAttribute('data-src') || im.getAttribute('data-original') || im.getAttribute('data-lazy')
      || im.getAttribute('data-srcset');
    if (cand) consider(cand, im, Math.round(r.width), Math.round(r.height), im.naturalWidth || 0, im.naturalHeight || 0);
  });

  // Gallerier byggda pa CSS background-image.
  document.querySelectorAll('div, section, a, li, span').forEach((el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 140 || r.height < 100) return;
    let bg = '';
    try { bg = getComputedStyle(el).backgroundImage || ''; } catch (e) { return; }
    const m = bg.match(/url\(["']?(.*?)["']?\)/i);
    if (m && m[1]) consider(m[1], el, Math.round(r.width), Math.round(r.height), 0, 0);
  });

  // Familje-svep: hamta syskonbilder ur rakoden utifran de bekraftade fotonas sokvag.
  // Jamforelsen sker pa NORMALISERAD form, sa /1440/... matchar /... (homeq.se).
  const prefixes = {};
  picked.forEach((p) => {
    const n = idOf(p.url);
    const cut = n.lastIndexOf('/');
    if (cut > 8) prefixes[n.slice(0, cut + 1)] = 1;
  });
  const prefixList = Object.keys(prefixes).slice(0, 8);
  if (prefixList.length) {
    const urlRe = /https?:\/\/[^\s"'<>()]+?\.(?:jpe?g|png|webp|avif)/gi;
    let m;
    while ((m = urlRe.exec(flat))) {
      const u = m[0];
      const id = idOf(u);
      if (!prefixList.some((p) => id.indexOf(p) === 0)) continue;
      if (denyId[id] || seenId[id] || BAD.test(u)) continue;
      seenId[id] = 1;
      picked.push({ url: u, id: id });
    }
  }

  // Sajtspecifika boosters (ger HELA galleriet aven nar det ar lazy-laddat).
  const add = (u) => { const id = idOf(u); if (!denyId[id] && !seenId[id]) { seenId[id] = 1; picked.unshift({ url: u, id: id }); } };
  let mm;
  if (/qasa/i.test(location.hostname)) {
    const reQasa = /\/img\/([a-f0-9]{16,})\.(jpe?g|png|webp)/gi;
    while ((mm = reQasa.exec(flat))) {
      add('https://img.qasa.se/unsafe/adaptive-fit-in/1200x1200/https://qasa-static-prod.s3-eu-west-1.amazonaws.com/img/' + (mm[1] + '.' + mm[2]).toLowerCase());
    }
  }
  // AIRBNB-GALLERI: sidan bar sin EGNA fotolista som "baseUrl"-poster (samma data som
  // "Visa alla foton"/Fotorundturen renderar). Den listan ar den enda sanningen: den saknar
  // grannannonser, vardavatar, kartor och ikoner. Verifierat pa /rooms/43473343: 29 foton,
  // och lika manga BADE fore och efter att galleriet oppnats - inget klick behovs.
  if (/airbnb/i.test(location.hostname)) {
    const KEY = String.fromCharCode(34) + "baseUrl" + String.fromCharCode(34) + ":" + String.fromCharCode(34);
    const QUOTE = String.fromCharCode(34);
    const gallery = [];
    const seenG = {};
    let at = 0;
    while (true) {
      const st = flat.indexOf(KEY, at);
      if (st < 0) break;
      const s2 = st + KEY.length;
      const en = flat.indexOf(QUOTE, s2);
      if (en < 0) break;
      at = en;
      const u = flat.slice(s2, en);
      if (u.indexOf("muscache") < 0) continue;
      if (roomId && u.indexOf("Hosting-" + roomId + "/") < 0) continue;
      if (!roomId && u.indexOf("Hosting-") < 0) continue;
      if (!seenG[u]) { seenG[u] = 1; gallery.push(u); }
    }
    // Ersatt allt annat: pa Airbnb ar det BARA fotolistan som galler.
    if (gallery.length) {
      picked.length = 0;
      gallery.forEach((u) => picked.push({ url: u, id: idOf(u) }));
    }
  }

  return { html: html, url: pageUrl, photos: picked.map((p) => p.url).slice(0, 100) };
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: harvestPage });
    const data = (res && res.result) || {};
    await chrome.storage.local.set({ handoff: { html: data.html || '', url: data.url || '', photos: data.photos || [], ts: Date.now() } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('review.html') });
  } catch (e) {
    // activeTab isn't granted on restricted pages (chrome://, the Web Store, PDF viewer…).
    await chrome.storage.local.set({ handoff: { error: String(e && e.message || e), ts: Date.now() } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('review.html') });
  }
});
