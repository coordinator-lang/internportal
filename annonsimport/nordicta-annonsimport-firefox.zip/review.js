/* ── Konfiguration ─────────────────────────────────────────────────────── */
const CFG = {
  fnBase:    'https://ruznxfmqarwlkyntxliq.supabase.co/functions/v1',
  extractFn: 'extract-listing',
  createFn:  'create-listing-item',
  // Bade lankade foton OCH egna filer gar hit sedan 2026-09-23. upload-landlord-photo
  // (hyresvardformularets) anvands inte langre - se kommentaren i uploadFiles.
  photoUrlFn:'import-photo-url',
  columnId:  'filer',
  itemUrl:   id => `https://nordicta.monday.com/boards/1453497707/pulses/${id}`
};
const MAX_PHOTOS = 40;

/* ── Extension-handoff: sidan som lästes i din webbläsare ──────────────── */
let HANDOFF = { html:'', url:'', photos:[] };
// Lankfaltet ligger dolt sa lange sidan kommer fran fliken man klickade pa. Utan skord
// (tomt formulär, misslyckad skord, sidan oppnad utanfor tillagget) ar det enda vagen in
// for en annons - da maste det fram.
function showUrlField(on){
  const el = document.getElementById('urlField');
  if(el) el.style.display = on ? '' : 'none';
}
// Rubrik- och hjalptexterna beskriver skorden ("sidan du klickade på"). Stammer inte i det
// tomma formularet - skriv om dem i stallet for att lata dem ljuga.
function describeBlank(){
  const lead = document.querySelector('header .header-inner p');
  if(lead) lead.innerHTML = 'Fyll i uppgifterna själv och lägg till dina egna bilder — eller klistra in en länk/annonstext och låt AI:n läsa. Granska och importera till <strong>HV&nbsp;-&nbsp;Databas</strong>.';
  const hint = document.querySelector('.card.lead .hint');
  if(hint) hint.textContent = 'Ingen sida läst. Fyll i fälten längre ned, eller ge AI:n något att läsa: en länk, annonstexten, eller bilder du laddar upp.';
  const btn = document.getElementById('btnAI');
  if(btn) btn.textContent = 'Läs in med AI →';
  // Utan skordad sida ar den har rutan inte "extra info ovanpa annonsen" - den ar hela
  // underlaget. Sag det, sa man vet att man kan klistra in annonsen rakt in och trycka las in
  // (tillsammans med egna bilder) utan att rora resten av formularet.
  const ta = document.getElementById('aiInstruction');
  if(ta){
    const lab = ta.closest('.field') && ta.closest('.field').querySelector('label');
    if(lab) lab.innerHTML = 'Annonstext eller extra info till AI:n <span class="opt">(klistra in hela annonsen om du har den)</span>';
    ta.placeholder = 'Klistra in annonstexten här — eller bara det du vet: adress, hyra, telefon, "allt ingår".';
  }
}
(function initHandoff(){
  const srcBox = document.getElementById('srcBox');
  if(!srcBox) return;
  // ?blank=1 = anvandaren valde "tomt formulär" (hogerklick pa ikonen, eller klick utanfor en
  // webbsida). Ingen sida ska lasas - visa falten direkt sa man kan borja fylla i.
  if(new URLSearchParams(location.search).get('blank') === '1'){
    srcBox.innerHTML = '<strong>Tomt formulär</strong> — ingen sida läst. Fyll i fälten och lägg till dina egna bilder.'
      + '<div style="margin-top:6px;color:var(--muted)">Vill du ändå läsa av något: klistra in annonsens <strong>länk</strong> nedan, eller annonstexten i rutan för extra info — eller ladda upp bilder och kryssa i bildavläsningen.</div>';
    try{ chrome.storage.local.remove('handoff'); }catch(_){}
    showUrlField(true);
    describeBlank();
    setReviewVisible(true);
    document.getElementById('reviewBanner').textContent = 'Fyll i fälten för hand.';
    return;
  }
  if(!(window.chrome && chrome.storage && chrome.storage.local)){
    srcBox.textContent = 'Öppnad utanför tillägget – ingen sida läst.';
    showUrlField(true); describeBlank(); return;
  }
  chrome.storage.local.get('handoff', (res)=>{
    const h = res && res.handoff;
    if(!h || h.error || !h.html){
      srcBox.innerHTML = (h && h.error)
        ? 'Kunde inte läsa sidan: '+esc(h.error)+' — öppna en vanlig annonssida och klicka på ikonen.'
        : 'Ingen sida läst. Öppna en annons (Qasa/Airbnb …) och klicka på tilläggets ikon.';
      showUrlField(true); describeBlank();
      return;
    }
    HANDOFF = { html:h.html, url:h.url||'', photos:Array.isArray(h.photos)?h.photos:[] };
    document.getElementById('url').value = HANDOFF.url;
    srcBox.innerHTML = 'Läst från: <span class="src-url">'+esc(HANDOFF.url||'(okänd sida)')+'</span> · <span class="src-count">'+HANDOFF.photos.length+' foton</span> hittade på sidan.'
      + '<div style="margin-top:6px;color:var(--muted)">Lägg till extra info nedan om du vill (telefon, exakt adress, särskild instruktion) — klicka sedan <strong>Läs in från sidan</strong>.</div>';
    if(HANDOFF.photos.length < 3){
      srcBox.innerHTML += '<div style="margin-top:6px;color:var(--accent-dark)">Hittade bara '
        + HANDOFF.photos.length + ' foto. Vissa sajter laddar bilderna forst nar galleriet oppnas '
        + '&mdash; oppna annonsens <strong>bildgalleri</strong> och klicka pa tillaggets ikon igen.</div>';
    }
    try{ chrome.storage.local.remove('handoff'); }catch(_){}   // så nästa gång inte återanvänder gammal sida
    // Ingen auto-inläsning: användaren ska hinna fylla i extra info först.
    const inp = document.getElementById('aiInstruction');
    if(inp) inp.focus();
  });
})();

/* ── Bekvämligheter ─────────────────────────────────────────────────────
 * Var fyra fritextfalt (sv + en for bekvamligheter, sv + en for parkering). Kollegorna
 * skulle alltsa skriva engelska namn for hand och traffa formulärets exakta skrivsatt -
 * annars matchade det inte i HV-Databas. Nu kryssrutor med SVENSKA etiketter, precis som i
 * hyresvardformuläret; engelskan fylls i automatiskt ur paret.
 *
 * LISTAN AR HYRESVARDFORMULARETS SEKTION 5, i formulärets egen ordning - inte var egen.
 * OBS: formuläret har fler kryssrutor an sa (Sang, Soffa, Matbord, Koksutrustning,
 * Garderob), men de ligger i SEKTION 4 'Mobleringsgrad' och hor alltsa inte hit.
 * Sektion 5 ar 19 poster, och sista ar Parkering. Kontrolleras av tester/test-amenities.mjs.
 *
 * Parkering fungerar som i formuläret: pillret avslojar en meny med typ. Den skriver till
 * parking_label_sv/en - INTE till bekvamlighetslistan - sa payloaden till Make ser ut
 * precis som forut.
 */
const AMENITY_PAIRS = [
  ['Wi-Fi','Wi-Fi'], ['TV','TV'], ['Kök','Kitchen'], ['Trinettkök','Kitchenette'],
  ['Mikrovågsugn','Microwave'], ['Ugn','Oven'], ['Diskmaskin','Dishwasher'],
  ['Kaffemaskin','Coffee machine'], ['Tvättmaskin','Washing machine'],
  ['Torktumlare','Tumble dryer'], ['Tvättstuga','Laundry room'], ['Hårtork','Hair dryer'],
  ['Luftkonditionering','Air conditioning'], ['Städredskap','Cleaning supplies'],
  ['Balkong','Balcony'], ['Hiss','Elevator'], ['Förråd','Storage'],
  ['Cykelförvaring','Bike storage'],
];
const PARKING_SV = 'Parkering', PARKING_EN = 'Parking';
// Formulärets tre typer, i formulärets ordning.
const PARKING_OPTS = [
  ['', 'Välj typ av parkering', ''],
  ['Parkering (betald)','Parkering (betald)','Parking (paid)'],
  ['Parkering (gata)','Parkering (gata)','Parking (street)'],
  ['Parkering (ingår)','Parkering (ingår)','Parking (included)'],
];
const amNorm = (x) => String(x||'').toLowerCase().split(' ').join('').split('-').join('').split('.').join('');

function buildAmenityUI(){
  const grid = document.getElementById('amenityGrid');
  const sel = document.getElementById('parkingSel');
  if(!grid || !sel) return;
  const pill = (sv,en,extra)=>
    `<label class="amenity"${extra||''}><input type="checkbox" data-sv="${escapeName(sv)}" data-en="${escapeName(en)}">`+
    `<span>${escapeName(sv)}</span></label>`;
  grid.innerHTML = AMENITY_PAIRS.map(([sv,en])=>pill(sv,en)).join('')
    + pill(PARKING_SV, PARKING_EN, ' data-parking="1"');   // sist, som i formuläret
  sel.innerHTML = PARKING_OPTS.map(([v,label])=>`<option value="${escapeName(v)}">${escapeName(label)}</option>`).join('');
  grid.addEventListener('change', fieldsFromAmenityUI);
  sel.addEventListener('change', fieldsFromAmenityUI);
}
const parkingBox = () => document.querySelector('#amenityGrid label[data-parking] input');

// Kryssrutor -> de dolda falten (bada sprak). Ordningen foljer listan, inte klickordningen,
// sa samma urval alltid ger samma strang.
function fieldsFromAmenityUI(){
  const f = document.getElementById('form');
  const sv = [], en = [];
  document.querySelectorAll('#amenityGrid label:not([data-parking]) input:checked').forEach(cb=>{
    sv.push(cb.dataset.sv); en.push(cb.dataset.en);
  });
  if(f.elements['amenities_sv']) f.elements['amenities_sv'].value = sv.join(', ');
  if(f.elements['amenities_en']) f.elements['amenities_en'].value = en.join(', ');
  // Parkering: pillret avgor OM, menyn avgor VILKEN typ. Panelen visas bara nar pillret ar i.
  const pb = parkingBox();
  const på = !!(pb && pb.checked);
  const detalj = document.getElementById('parkingDetail');
  if(detalj) detalj.hidden = !på;
  const sel = document.getElementById('parkingSel');
  if(!på){
    if(f.elements['parking_label_sv']) f.elements['parking_label_sv'].value = '';
    if(f.elements['parking_label_en']) f.elements['parking_label_en'].value = '';
    return;
  }
  if(!sel.value){   // parkering finns men typ inte vald an
    if(f.elements['parking_label_sv']) f.elements['parking_label_sv'].value = PARKING_SV;
    if(f.elements['parking_label_en']) f.elements['parking_label_en'].value = PARKING_EN;
    return;
  }
  const opt = PARKING_OPTS.find(o=>o[0]===sel.value);
  if(!opt){
    // Ett varde ur annonsen som inte finns i listan: behall det pa svenska, lamna engelskan tom
    // (vi hittar inte pa en oversattning) sa granskaren ser att den behover valjas.
    if(f.elements['parking_label_sv']) f.elements['parking_label_sv'].value = sel.value;
    if(f.elements['parking_label_en']) f.elements['parking_label_en'].value = '';
    return;
  }
  if(f.elements['parking_label_sv']) f.elements['parking_label_sv'].value = opt[0];
  if(f.elements['parking_label_en']) f.elements['parking_label_en'].value = opt[2];
}

// De dolda falten -> kryssrutorna. Kors efter AI-inlasning och efter bildavlasningen, och
// matchar bade svenska och engelska namn skiftlagesokansligt (AI:n kan svara pa endera).
function amenityUIFromFields(){
  const f = document.getElementById('form');
  const raw = String(f.elements['amenities_sv']?.value||'') + ',' + String(f.elements['amenities_en']?.value||'');
  const want = new Set(raw.split(',').map(x=>amNorm(x)).filter(Boolean));
  document.querySelectorAll('#amenityGrid input').forEach(cb=>{
    cb.checked = want.has(amNorm(cb.dataset.sv)) || want.has(amNorm(cb.dataset.en));
  });
  // OBS: slog forut ihop falten med '|', vilket gjorde strangen icke-tom aven nar bada var
  // tomma - da kryssades parkeringspillret i pa varenda annons.
  const parkSv = String(f.elements['parking_label_sv']?.value||'').trim();
  const parkEn = String(f.elements['parking_label_en']?.value||'').trim();
  const park = parkSv + ' ' + parkEn;
  const sel = document.getElementById('parkingSel');
  const p = amNorm(park);
  // AI:n kan ocksa lagga 'Parkering' i sjalva bekvamlighetslistan - da raknas det ocksa.
  const parkNamnd = (parkSv + parkEn).length > 0 || want.has(amNorm(PARKING_SV)) || want.has(amNorm(PARKING_EN));
  const pb = parkingBox();
  if(pb) pb.checked = parkNamnd;
  const matchar = (o) => (o[0] && p.indexOf(amNorm(o[0]))>=0) || (o[2] && p.indexOf(amNorm(o[2]))>=0);
  const hit = PARKING_OPTS.slice(1).find(matchar);
  // Star det nagot vi inte kanner igen ('Garageplats i huset') far det INTE forsvinna tyst -
  // lagg in det som ett eget val sa granskaren ser vad annonsen sa och kan byta till ratt typ.
  const ratext = String(f.elements['parking_label_sv']?.value || f.elements['parking_label_en']?.value || '').trim();
  sel.querySelectorAll('option[data-ad]').forEach(o=>o.remove());
  if(!hit && ratext && amNorm(ratext) !== amNorm(PARKING_SV) && amNorm(ratext) !== amNorm(PARKING_EN)){
    const o = document.createElement('option');
    o.value = ratext; o.textContent = ratext + '  (ur annonsen)'; o.dataset.ad = '1';
    sel.appendChild(o);
    sel.value = ratext;
    return;   // behall texten som den star; fieldsFromAmenityUI skulle nolla den
  }
  sel.value = hit ? hit[0] : '';
  fieldsFromAmenityUI();   // skriv tillbaka normaliserat, sa falten alltid speglar rutorna
}

/* ── Bäddset & driftkostnader ──────────────────────────────────────────── */
const BED = [['included','Ingår'],['extra_cost','Mot tillägg'],['not_included','Ingår ej']];
document.querySelectorAll('select.bedset').forEach(sel=> BED.forEach(([v,t])=>{ const o=document.createElement('option'); o.value=v; o.textContent=t; sel.appendChild(o); }));
const UTILS = [['electricity','El'],['heating','Värme'],['internet','Internet'],['water','Vatten']];
const UST   = [['included','Ingår'],['partial','Delvis'],['not_included','Ingår ej']];
const utilRows = document.getElementById('utilRows');
UTILS.forEach(([key,name])=>{
  const row=document.createElement('div'); row.className='util-row';
  const sel=document.createElement('select'); sel.dataset.util=key;
  UST.forEach(([v,t])=>{ const o=document.createElement('option'); o.value=v; o.textContent=t; sel.appendChild(o); });
  const amt=document.createElement('input'); amt.className='amt hidden'; amt.placeholder='belopp'; amt.dataset.amt=key;
  sel.addEventListener('change',()=> amt.classList.toggle('hidden', sel.value!=='partial'));
  const lab=document.createElement('div'); lab.className='uname'; lab.textContent=name;
  row.append(lab, sel, amt); utilRows.appendChild(row);
});
const utilAll = document.getElementById('utilAll');
const utilDetail = document.getElementById('utilDetail');
utilAll.addEventListener('change',()=> utilDetail.classList.toggle('hidden', utilAll.checked));

/* ── Bildlänk-räknare ──────────────────────────────────────────────────── */
const galleryEl = document.getElementById('gallery');
const parseGallery = () => [...new Set(galleryEl.value.split('\n').map(x=>x.trim()).filter(x=>/^https?:\/\//i.test(x)))];
const updateCount = ()=>{ document.getElementById('photoCount').textContent = `(${parseGallery().length} länkar)`; renderGalPreview(); };
galleryEl.addEventListener('input', updateCount);

/* Förhandsbilder på galleriet. På okända sajter (tyska portaler m.fl.) kan skörden aldrig bli
   100 % träffsäker — därför visas varje bild som ska importeras, med × för att ta bort. */
const galPreview = document.getElementById('galPreview');
const galHint = document.getElementById('galHint');
function removeGalleryUrl(u){
  galleryEl.value = parseGallery().filter(x=>x!==u).join('\n');
  updateCount();
}
// Flytta en annonsbild i ordningen. Forsta bilden blir omslagsbild i HV-Databas, sa
// granskaren maste kunna styra ordningen - inte bara ta bort.
function moveGalleryUrl(u,dir){
  const urls=parseGallery(); const i=urls.indexOf(u); const to=i+dir;
  if(i<0||to<0||to>=urls.length) return;
  urls.splice(to,0,urls.splice(i,1)[0]);
  galleryEl.value=urls.join(String.fromCharCode(10)); updateCount();
}
// Dra-och-slapp i rutnatet. Pilarna rackte inte: att pila bild 21 till forstaplats ar 20 klick.
// Semantiken ar insattning (som i en fotolista), inte byte - bilden landar dar markoren star.
// Pilarna ligger kvar for pekskarmar, dar HTML5-drag inte finns.
let galDragFrom = null;
function clearGalMarks(){
  galPreview.querySelectorAll('.gal-item').forEach(el=>{ el.classList.remove('ins-before'); el.classList.remove('ins-after'); });
}
// Insattningsplats 0..len: vanster halva av en tile = fore den, hoger halva = efter den.
function galDropIndex(item, clientX){
  const i = +item.dataset.idx;
  const r = item.getBoundingClientRect();
  return clientX > r.left + r.width / 2 ? i + 1 : i;
}
function moveGalleryTo(from, insertAt){
  const urls = parseGallery();
  if(from < 0 || from >= urls.length) return;
  let to = insertAt;
  if(to > from) to--;                 // efter borttagningen kryper allt efter from ett steg
  if(to < 0) to = 0;
  if(to > urls.length - 1) to = urls.length - 1;
  if(to === from) return;
  urls.splice(to, 0, urls.splice(from, 1)[0]);
  galleryEl.value = urls.join(String.fromCharCode(10));
  updateCount();                      // ritar om rutnatet med ny numrering
  const el = galPreview.querySelectorAll('.gal-item')[to];
  if(el) el.classList.add('moved');
}
function galDragEnd(){
  galDragFrom = null;
  galPreview.classList.remove('dragging-active');
  galPreview.querySelectorAll('.gal-item').forEach(el=>el.classList.remove('dragging'));
  clearGalMarks();
}
function wireGalDrag(){
  galPreview.querySelectorAll('.gal-item').forEach(item=>{
    item.addEventListener('dragstart',e=>{
      galDragFrom = +item.dataset.idx;
      item.classList.add('dragging');
      galPreview.classList.add('dragging-active');
      e.dataTransfer.effectAllowed = 'move';
      // Firefox startar inte draget alls om dataTransfer ar tomt.
      try{ e.dataTransfer.setData('text/plain', String(galDragFrom)); }catch(_){}
    });
    item.addEventListener('dragend', galDragEnd);
    item.addEventListener('dragover',e=>{
      if(galDragFrom === null) return;   // filer som dras hit ska inte fangas
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      const at = galDropIndex(item, e.clientX);
      clearGalMarks();
      item.classList.add(at > +item.dataset.idx ? 'ins-after' : 'ins-before');
    });
    item.addEventListener('drop',e=>{
      if(galDragFrom === null) return;
      e.preventDefault();
      const at = galDropIndex(item, e.clientX);
      const from = galDragFrom;
      galDragEnd();                      // stada FORE omritningen - noden forsvinner da
      moveGalleryTo(from, at);
    });
  });
}
// Slapp i tomrummet efter sista bilden = lagg sist.
if(galPreview){
  galPreview.addEventListener('dragover',e=>{ if(galDragFrom !== null && e.target === galPreview){ e.preventDefault(); clearGalMarks(); } });
  galPreview.addEventListener('drop',e=>{
    if(galDragFrom === null || e.target !== galPreview) return;
    e.preventDefault();
    const from = galDragFrom;
    galDragEnd();
    moveGalleryTo(from, parseGallery().length);
  });
}
function renderGalPreview(){
  if(!galPreview) return;
  const urls = parseGallery();
  if(galHint) galHint.style.display = urls.length ? 'block' : 'none';
  const por=document.getElementById('photoOrderRow');
  if(por) por.style.display = (urls.length && currentFiles.length) ? 'flex' : 'none';
  if(!urls.length){ galPreview.innerHTML=''; return; }
  galPreview.innerHTML = urls.map((u,i)=>`
    <div class="gal-item" draggable="true" data-idx="${i}" data-url="${escapeName(u)}" title="Dra för att ändra ordning">
      <img src="${escapeName(u)}" alt="" loading="lazy" referrerpolicy="no-referrer" draggable="false">
      <span class="gal-no">${i+1}</span>
      <button type="button" class="gal-del" data-url="${escapeName(u)}" title="Ta bort bilden">×</button>
      <span class="gal-move">
        <button type="button" class="gal-left" data-url="${escapeName(u)}" ${i===0?'disabled':''} title="Flytta tidigare">&#9664;</button>
        <button type="button" class="gal-right" data-url="${escapeName(u)}" ${i===urls.length-1?'disabled':''} title="Flytta senare">&#9654;</button>
      </span>
    </div>`).join('');
  galPreview.querySelectorAll('.gal-del').forEach(b=>b.addEventListener('click',()=>removeGalleryUrl(b.dataset.url)));
  galPreview.querySelectorAll('.gal-left').forEach(b=>b.addEventListener('click',()=>moveGalleryUrl(b.dataset.url,-1)));
  galPreview.querySelectorAll('.gal-right').forEach(b=>b.addEventListener('click',()=>moveGalleryUrl(b.dataset.url,+1)));
  wireGalDrag();
  // Markera bilder som inte går att ladda (död länk / hotlink-skydd) så de kan tas bort.
  galPreview.querySelectorAll('img').forEach(im=>{
    im.addEventListener('error',()=>im.closest('.gal-item')?.classList.add('bad'));
  });
}

/* ── Fotouppladdare (filer) ────────────────────────────────────────────── */
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const fileList = document.getElementById('fileList');
let currentFiles = [];
const thumbCache = new Map();
function thumbUrl(f){ if(!thumbCache.has(f)) thumbCache.set(f, URL.createObjectURL(f)); return thumbCache.get(f); }
function pruneThumbs(){ for(const [f,u] of thumbCache){ if(!currentFiles.includes(f)){ URL.revokeObjectURL(u); thumbCache.delete(f);} } }
function escapeName(s){ return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
/* HEIC-stöd: Chrome/Edge kan inte avkoda iPhone-HEIC (createImageBitmap kastar → bilden
   laddades förr upp i original). Konvertera HEIC→JPEG i webbläsaren först, sedan går den
   vanliga komprimeringen igenom. heic2any laddas bara när en HEIC faktiskt dyker upp. */
let heicLibPromise=null;
function loadHeicLib(){
  if(window.heic2any) return Promise.resolve(window.heic2any);
  if(!heicLibPromise){
    heicLibPromise=new Promise((resolve,reject)=>{
      const s=document.createElement('script');
      // Buntad lokalt i tillägget (lib/) — MV3 tillåter inte kod från CDN, och kollegorna
      // ska inte behöva installera något extra.
      s.src='lib/heic2any.min.js';
      s.onload=()=>resolve(window.heic2any);
      s.onerror=()=>{ heicLibPromise=null; reject(new Error('Kunde inte ladda HEIC-konverteraren (kräver internet).')); };
      document.head.appendChild(s);
    });
  }
  return heicLibPromise;
}
function isHeic(f){ return /\.(heic|heif)$/i.test(f.name||'') || /^image\/hei[cf]/i.test(f.type||''); }
async function toJpegIfHeic(file){
  if(!isHeic(file)) return file;
  const heic2any=await loadHeicLib();
  // heic2any gör jobbet i en blob-Worker och har INGEN reservväg på huvudtråden — om
  // webbläsarens tilläggs-CSP stoppar den workern blir löftet aldrig uppfyllt. Timeout så
  // uppladdningen aldrig hänger tyst; anroparen visar då ett tydligt meddelande.
  const out=await Promise.race([
    heic2any({ blob:file, toType:'image/jpeg', quality:0.9 }),
    new Promise((_,rej)=>setTimeout(()=>rej(new Error('HEIC_TIMEOUT')), 20000))
  ]);
  const blob=Array.isArray(out)?out[0]:out;
  return new File([blob], (file.name||'bild').replace(/\.[^.]+$/,'')+'.jpg', {type:'image/jpeg', lastModified:file.lastModified});
}
const dzStatus=document.getElementById('dzStatus');
function setDzStatus(msg){ if(!dzStatus) return; if(msg){ dzStatus.textContent=msg; dzStatus.classList.add('show'); } else dzStatus.classList.remove('show'); }
let addBusy=false;
async function addFiles(newFiles){
  // Acceptera riktiga bilder + HEIC/HEIF även när Windows ger dem tom MIME-typ.
  const imgs = Array.from(newFiles).filter(f=>(f.type||'').startsWith('image/') || isHeic(f));
  const heicCount = imgs.filter(isHeic).length;
  let rejected=0, failed=0, added=0;
  addBusy=true;
  if(heicCount) setDzStatus(`Konverterar ${heicCount} HEIC-bild${heicCount>1?'er':''} till JPEG…`);
  for(const src of imgs){
    if(currentFiles.length>=MAX_PHOTOS){ rejected++; continue; }
    // Dubblettkoll på originalfilen (före ev. konvertering).
    if(currentFiles.some(c=>c._srcName===src.name && c._srcSize===src.size && c._srcMod===src.lastModified)) continue;
    let f=src;
    try{ f=await toJpegIfHeic(src); }
    catch(err){ failed++; console.warn('HEIC-konvertering misslyckades:',err); continue; }
    try{ f._srcName=src.name; f._srcSize=src.size; f._srcMod=src.lastModified; }catch(_){}
    currentFiles.push(f); added++;
  }
  addBusy=false;
  setDzStatus(failed ? `${failed} HEIC-bild${failed>1?'er':''} kunde inte konverteras här. Använd webbverktyget på internportalen för dessa filer, eller spara om dem som JPG.` : '');
  if(failed) setTimeout(()=>{ if(!addBusy) setDzStatus(''); }, 6000);
  renderFiles(rejected);
}
function removeFile(i){ currentFiles.splice(i,1); renderFiles(); }
function moveFile(i,dir){ const to=i+dir; if(to<0||to>=currentFiles.length) return; const [f]=currentFiles.splice(i,1); currentFiles.splice(to,0,f); renderFiles(); flash(to); }
function flash(i){ const el=fileList.querySelectorAll('.file-item')[i]; if(el) el.classList.add('moved'); }
let dragFrom=null;
function wireDrag(){
  fileList.querySelectorAll('.file-item').forEach(item=>{
    item.addEventListener('dragstart',e=>{ dragFrom=+item.dataset.idx; item.classList.add('dragging'); e.dataTransfer.effectAllowed='move'; try{ e.dataTransfer.setData('text/plain', String(dragFrom)); }catch(_){} });
    item.addEventListener('dragend',()=>{ item.classList.remove('dragging'); fileList.querySelectorAll('.file-item').forEach(el=>el.classList.remove('drag-over')); dragFrom=null; });
    item.addEventListener('dragover',e=>{ e.preventDefault(); item.classList.add('drag-over'); });
    item.addEventListener('dragleave',()=>item.classList.remove('drag-over'));
    item.addEventListener('drop',e=>{ e.preventDefault(); item.classList.remove('drag-over'); const to=+item.dataset.idx; if(dragFrom===null||dragFrom===to) return; const [f]=currentFiles.splice(dragFrom,1); currentFiles.splice(to,0,f); dragFrom=null; renderFiles(); flash(to); });
  });
}
function renderFiles(rejected=0){
  pruneThumbs();
  if(!currentFiles.length){ fileList.innerHTML=''; return; }
  const last=currentFiles.length-1;
  let html = currentFiles.length>=2 ? `<div class="file-reorder-hint">Ändra ordningen med ▲▼ (eller dra på dator) — första bilden visas först.</div>` : '';
  html += currentFiles.map((f,i)=>`
    <div class="file-item" draggable="true" data-idx="${i}">
      <span class="file-drag" aria-hidden="true">⋮⋮</span>
      <img class="file-thumb" src="${thumbUrl(f)}" alt="" draggable="false">
      <span class="file-name">${escapeName(f.name)}</span>
      <span class="file-order"><button type="button" class="file-up" data-idx="${i}" ${i===0?'disabled':''}>▲</button><button type="button" class="file-down" data-idx="${i}" ${i===last?'disabled':''}>▼</button></span>
      <button type="button" class="file-remove" data-idx="${i}" title="Ta bort">×</button>
    </div>`).join('');
  if(rejected>0) html += `<div class="banner err" style="margin-top:8px">För många bilder — de extra togs inte med (max ${MAX_PHOTOS}).</div>`;
  fileList.innerHTML=html;
  fileList.querySelectorAll('.file-remove').forEach(b=>b.addEventListener('click',()=>removeFile(+b.dataset.idx)));
  fileList.querySelectorAll('.file-up').forEach(b=>b.addEventListener('click',()=>moveFile(+b.dataset.idx,-1)));
  fileList.querySelectorAll('.file-down').forEach(b=>b.addEventListener('click',()=>moveFile(+b.dataset.idx,+1)));
  wireDrag();
}
dropZone.addEventListener('click',()=>fileInput.click());
// Bara riktiga filer ska tandas har - annars lyser slappzonen nar man drar om annonsbilderna.
const dtHasFiles = e => { try{ return Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0; }catch(_){ return true; } };
dropZone.addEventListener('dragover',e=>{ if(!dtHasFiles(e)) return; e.preventDefault(); dropZone.classList.add('over'); });
dropZone.addEventListener('dragleave',()=>dropZone.classList.remove('over'));
dropZone.addEventListener('drop',e=>{ if(!dtHasFiles(e)) return; e.preventDefault(); dropZone.classList.remove('over'); addFiles(e.dataTransfer.files); });
fileInput.addEventListener('change',()=>{ addFiles(fileInput.files); fileInput.value=''; });

/* ── Adressökning (Photon/OpenStreetMap) — portad från hyresvärdformulär v49.1 ── */
const acInput = document.getElementById('acInput');
const acList  = document.getElementById('autocompleteList');
let acTimer=null, acResults=[], acActiveIdx=-1;
if(acInput){
  acInput.addEventListener('input',()=>{ const q=acInput.value.trim(); clearTimeout(acTimer); if(q.length<3){ hideAC(); return; } acTimer=setTimeout(()=>fetchAC(q),300); });
  acInput.addEventListener('keydown',e=>{
    if(!acList.classList.contains('visible')) return;
    if(e.key==='ArrowDown'){ e.preventDefault(); acActiveIdx=Math.min(acActiveIdx+1,acResults.length-1); updateAC(); }
    else if(e.key==='ArrowUp'){ e.preventDefault(); acActiveIdx=Math.max(acActiveIdx-1,0); updateAC(); }
    else if(e.key==='Enter'&&acActiveIdx>=0){ e.preventDefault(); e.stopPropagation(); pickAC(acResults[acActiveIdx]); }
    else if(e.key==='Escape'){ hideAC(); }
  });
  document.addEventListener('click',e=>{ if(!e.target.closest('.ac-wrap')) hideAC(); });
}
async function fetchAC(q){
  acList.innerHTML='<div class="autocomplete-loading">Söker…</div>'; acList.classList.add('visible');
  try{
    const res=await fetch('https://photon.komoot.io/api/?lang=default&limit=6&q='+encodeURIComponent(q));
    if(!res.ok){ hideAC(); return; }
    const data=await res.json();
    acResults=(data.features||[]).map(f=>({
      name:f.properties.name||'', street:f.properties.street||'', housenumber:f.properties.housenumber||'',
      postcode:f.properties.postcode||'', city:f.properties.city||f.properties.town||f.properties.village||'',
      country:f.properties.country||'', countrycode:f.properties.countrycode||'',
      lng:(f.geometry&&f.geometry.coordinates&&f.geometry.coordinates[0]!=null)?String(f.geometry.coordinates[0]):'',
      lat:(f.geometry&&f.geometry.coordinates&&f.geometry.coordinates[1]!=null)?String(f.geometry.coordinates[1]):''
    }));
    renderAC();
  }catch(err){ acList.innerHTML='<div class="autocomplete-empty">Sökning misslyckades — försök igen</div>'; }
}
function fmtAC(r){
  let line=''; if(r.street) line=r.street+(r.housenumber?' '+r.housenumber:''); else if(r.name) line=r.name;
  const tail=[r.postcode,r.city].filter(Boolean).join(' ');
  let out = (line&&tail) ? line+', '+tail : (line||tail||r.name||'Okänd adress');
  if(r.country&&r.countrycode&&r.countrycode.toLowerCase()!=='se') out+=', '+r.country;
  return out;
}
function renderAC(){
  if(!acResults.length){ acList.innerHTML='<div class="autocomplete-empty">Inga adresser hittades</div>'; return; }
  acActiveIdx=-1;
  acList.innerHTML=acResults.map((r,i)=>`
    <div class="autocomplete-item" data-idx="${i}">
      <svg class="pin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
      <div class="text">${escapeName(fmtAC(r))}</div>
    </div>`).join('');
  acList.querySelectorAll('.autocomplete-item').forEach(el=>el.addEventListener('click',()=>pickAC(acResults[+el.dataset.idx])));
}
function updateAC(){
  acList.querySelectorAll('.autocomplete-item').forEach((el,i)=>el.classList.toggle('active',i===acActiveIdx));
  const a=acList.querySelector('.autocomplete-item.active'); if(a) a.scrollIntoView({block:'nearest'});
}
function acSet(name,val){ const el=document.querySelector(`[name="${name}"]`); if(el) el.value=val; }
function pickAC(r){
  if(acInput) acInput.value=fmtAC(r);
  acSet('city', r.city||'');
  acSet('country', r.country||'');
  acSet('country_iso', (r.countrycode||'').toUpperCase());
  acSet('lat', r.lat||'');
  acSet('lng', r.lng||'');
  hideAC(); if(acInput) acInput.focus();
}
function hideAC(){ acList.classList.remove('visible'); acActiveIdx=-1; }
async function compressImage(file, maxDim=1600, quality=0.82){
  if(!file.type.startsWith('image/')) return file;
  try{
    const img=await createImageBitmap(file);
    const scale=Math.min(1, maxDim/Math.max(img.width,img.height));
    const w=Math.round(img.width*scale), h=Math.round(img.height*scale);
    const canvas=document.createElement('canvas'); canvas.width=w; canvas.height=h;
    canvas.getContext('2d').drawImage(img,0,0,w,h);
    const blob=await new Promise(r=>canvas.toBlob(r,'image/jpeg',quality));
    return new File([blob], file.name.replace(/\.[^.]+$/,'.jpg'), {type:'image/jpeg'});
  }catch(e){ return file; }
}

// Bilderna man laddar upp sjalv finns BARA i webblasaren - de har ingen adress som servern
// kan hamta, sa bildavlasningen sag dem inte alls forut. Skicka dem som data-URL:er i
// stallet. Mindre an uppladdningsvarianten (1024 px / 0.7): det racker gott for att se en
// diskmaskin, och haller nere bade tokens och vantetid.
async function filesForVision(files, max = 8){
  const out = [];
  for(const f of files.slice(0, max)){
    try{
      const small = await compressImage(f, 1024, 0.7);
      const b64 = await new Promise((res, rej)=>{
        const r = new FileReader();
        r.onload = ()=>res(String(r.result));
        r.onerror = ()=>rej(r.error || new Error('kunde inte läsa filen'));
        r.readAsDataURL(small);
      });
      if(b64.indexOf('data:image/') === 0) out.push(b64);
    }catch(e){ /* hoppa over just den bilden - aldrig fella hela inlasningen */ }
  }
  return out;
}

// Bara-bilder-lasningen ska ADDERA bekvamligheter, aldrig radera det nagon skrivit for hand.
function mergeAmenities(obj){
  const f = document.getElementById('form');
  const add = (nameField, val)=>{
    const el = f.elements[nameField]; if(!el) return;
    const have = el.value.split(',').map(x=>x.trim()).filter(Boolean);
    const low = new Set(have.map(x=>x.toLowerCase()));
    String(val || '').split(',').map(x=>x.trim()).filter(Boolean).forEach(x=>{
      if(!low.has(x.toLowerCase())){ low.add(x.toLowerCase()); have.push(x); }
    });
    el.value = have.join(', ');
  };
  add('amenities_sv', obj.amenities_sv);
  add('amenities_en', obj.amenities_en);
}

/* ── Fält & snabbfyll ──────────────────────────────────────────────────── */
const SELECT_FIELDS = ['landlord_type','property_type','furnished','rent_currency','bed_duvet','bed_pillow','bed_sheets','bed_towels'];
const TEXT_FIELDS = ['name','company','phone','country_iso','email','address','city','country','lat','lng','bedrooms','bed_places','bathrooms','showers','size','rent_amount','amenities_sv','amenities_en','parking_label_sv','parking_label_en','extra_info'];
function setReviewVisible(v){
  document.getElementById('reviewSection').classList.toggle('hidden', !v);
  document.getElementById('btnManual').textContent = v ? 'Dölj fälten' : 'Fyll i för hand';
}
function showReview(){ setReviewVisible(true); }
function prefillFromObject(obj){
  const f = document.getElementById('form');
  const set = (n,v)=>{ if(f.elements[n]!==undefined && v!==undefined && v!==null) f.elements[n].value = String(v); };
  TEXT_FIELDS.forEach(n=> n in obj && set(n,obj[n]));
  SELECT_FIELDS.forEach(n=>{ if(n in obj && obj[n]!=null && obj[n]!=='') set(n,obj[n]); });
  if(Array.isArray(obj.gallery)){ galleryEl.value = obj.gallery.join('\n'); updateCount(); }
  if(obj.utilities && typeof obj.utilities==='object'){
    utilAll.checked=false; utilDetail.classList.remove('hidden');
    UTILS.forEach(([key])=>{
      const sel=utilRows.querySelector(`select[data-util="${key}"]`);
      const amt=utilRows.querySelector(`input[data-amt="${key}"]`);
      const belopp=String(obj.utilities[key+'_amount'] ?? '').trim();
      let status=obj.utilities[key] || '';
      // Ett belopp hor ihop med "Delvis" - beloppsfaltet finns bara dar. Svarar AI:n
      // "ingår ej" OCH ett belopp visar vi Delvis, annars ser man rutan tom och beloppet
      // foljer inte med importen. (Rapporterat 2026-09-09.)
      if(belopp && status && status!=='included') status='partial';
      if(sel && status){ sel.value=status; sel.dispatchEvent(new Event('change')); }
      if(amt && belopp) amt.value=belopp;
    });
  } else if(String(obj.utilities_included)==='yes'){ utilAll.checked=true; utilDetail.classList.add('hidden'); }
}

/* ── Läs in med AI ─────────────────────────────────────────────────────── */
const aiStatus = document.getElementById('aiStatus');
document.getElementById('btnAI').addEventListener('click', async ()=>{
  const url = document.getElementById('url').value.trim();
  const instruction = document.getElementById('aiInstruction').value.trim();
  const readImages = document.getElementById('readImages').checked;
  const ownCount = readImages ? currentFiles.length : 0;
  // Egna bilder RACKER som underlag: da lases bara de, och ovriga falt lamnas i fred.
  const onlyOwn = !HANDOFF.html && !url && !instruction;
  if(onlyOwn && !ownCount){ aiStatus.textContent='Inget att läsa — öppna en annons och klicka på tilläggets ikon, klistra in adress/text ovan, eller ladda upp egna bilder och kryssa i bildavläsningen.'; return; }
  const btn=document.getElementById('btnAI'); btn.disabled=true; btn.innerHTML='<span class="spinner"></span>'+(onlyOwn?'Läser dina bilder…':(readImages?'Läser text + bilder…':'Läser…')); aiStatus.textContent='';
  try{
    const ownPhotos = ownCount ? await filesForVision(currentFiles) : [];
    const r = await fetch(`${CFG.fnBase}/${CFG.extractFn}`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ url: HANDOFF.url || url, html: HANDOFF.html || '', photos: HANDOFF.photos || [], photos_b64: ownPhotos, instruction, read_images: readImages }) });
    const j = await r.json();
    if(!r.ok || j.error){ throw new Error(typeof j.error==='object'?JSON.stringify(j.error):(j.error||('HTTP '+r.status))); }
    // Bara-bilder-svaret innehaller ENBART bekvamligheter - sla ihop dem med faltet i
    // stallet for att fylla i formularet (som annars hade nollat det man skrivit).
    if(j.via === 'photos') mergeAmenities(j.data || {});
    else prefillFromObject(j.data || {});
    amenityUIFromFields();   // kryssa i rutorna utifran det AI:n fyllde i
    showReview();
    const rb = document.getElementById('reviewBanner');
    if(j.read_failed){
      rb.classList.add('warn');
      rb.textContent = '⚠️ Sidan kunde inte läsas automatiskt' + (j.read_note ? ' ('+j.read_note+')' : '') + '. Bara det du angav i "extra info/instruktion" användes. Klistra in annonstexten där och läs in igen, eller fyll i fälten för hand — och lägg till bilderna manuellt.';
    } else {
      rb.classList.remove('warn');
      let msg = (j.via === 'photos')
        ? `AI:n (${j.model||'Claude'}) läste av dina bilder. Övriga fält är orörda.`
        : `AI:n (${j.model||'Claude'}) fyllde i fälten. Granska och rätta innan import — särskilt hyra, bäddset och att inga fel bilder kom med.`;
      if(j.vision){ msg += (j.vision.added && j.vision.added.length) ? ` Från bilderna lades till: ${j.vision.added.join(', ')}.` : ' Bilderna gav inga extra bekvämligheter.'; }
      rb.textContent = msg;
    }
    document.getElementById('reviewSection').scrollIntoView({behavior:'smooth', block:'start'});
  }catch(e){ aiStatus.textContent = 'Fel: '+e.message; }
  finally{ btn.disabled=false; btn.textContent='Läs in med AI →'; }
});
document.getElementById('btnManual').addEventListener('click',()=>{
  const willShow = document.getElementById('reviewSection').classList.contains('hidden');
  setReviewVisible(willShow);
  if(willShow){ document.getElementById('reviewBanner').textContent='Fyll i fälten för hand.'; document.getElementById('reviewSection').scrollIntoView({behavior:'smooth', block:'start'}); }
});
document.getElementById('btnFill').addEventListener('click',()=>{
  const raw=document.getElementById('aiJson').value.trim(); if(!raw) return;
  let obj; try{ obj=JSON.parse(raw); }catch(e){ alert('Kunde inte tolka JSON:\n'+e.message); return; }
  prefillFromObject(obj); showReview(); document.getElementById('reviewSection').scrollIntoView({behavior:'smooth', block:'start'});
});

buildAmenityUI();

/* ── Bygg payload ──────────────────────────────────────────────────────── */
function buildData(){
  const f = document.getElementById('form');
  const g = n => (f.elements[n]?.value ?? '').trim();
  const d = {};
  [...TEXT_FIELDS, ...SELECT_FIELDS].forEach(n=> d[n]=g(n));
  d.country_iso = d.country_iso.toUpperCase();
  d.gallery = parseGallery();
  d.photo_count = String(currentFiles.length + d.gallery.length);
  if (utilAll.checked){ d.utilities_included = 'yes'; }
  else {
    d.utilities = {};
    utilRows.querySelectorAll('select[data-util]').forEach(sel=>{
      const k=sel.dataset.util; d.utilities[k]=sel.value;
      const amt=utilRows.querySelector(`input[data-amt="${k}"]`);
      if(sel.value==='partial' && amt.value.trim()) d.utilities[k+'_amount']=amt.value.trim();
    });
  }
  return d;
}

/* ── Resultat-UI ───────────────────────────────────────────────────────── */
const resultEl = document.getElementById('result');
function banner(kind,msg){ return `<div class="banner ${kind}">${msg}</div>`; }
function esc(s){ return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }
function setBusy(on){ document.getElementById('btnImport').disabled=on; document.getElementById('btnPreview').disabled=on; }

document.getElementById('btnPreview').addEventListener('click', async ()=>{
  const d = buildData();
  if(!d.address && !(d.lat && d.lng)){ resultEl.innerHTML = `<div class="result-card">${banner('err','Fyll i en adress (eller lat + lng).')}</div>`; return; }
  setBusy(true);
  resultEl.innerHTML = `<div class="result-card"><h3>Förhandsgranskar…</h3><div class="status-line"><span class="dot run"></span> Geokodar och bygger payload</div></div>`;
  try{
    const r = await fetch(`${CFG.fnBase}/${CFG.createFn}?dry_run=1`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(d) });
    const j = await r.json();
    if(!r.ok || j.error){ throw new Error(typeof j.error==='object'?JSON.stringify(j.error):(j.error||('HTTP '+r.status))); }
    resultEl.innerHTML = `<div class="result-card">${banner('ok','Ingen post skapad — detta är vad “Importera” skulle skicka.')}
      <h3>Payload-förhandsvisning</h3>
      <div class="status-line"><span class="dot ok"></span> Geokod: lat ${esc(j.lat)}, lng ${esc(j.lng)}</div>
      <div class="status-line"><span class="dot ok"></span> Ort-taggar: ${esc((j.nearby||[]).join(', '))}</div>
      <div class="status-line"><span class="dot ok"></span> Foton: ${currentFiles.length} filer + ${d.gallery.length} länkar</div>
      <pre class="payload">${esc(JSON.stringify(j.payload,null,2))}</pre></div>`;
  }catch(e){ resultEl.innerHTML = `<div class="result-card">${banner('err','Förhandsgranskning misslyckades: '+esc(e.message))}</div>`; }
  finally{ setBusy(false); }
});

/* ── Import ────────────────────────────────────────────────────────────── */
document.getElementById('form').addEventListener('submit', async (ev)=>{
  ev.preventDefault();
  const d = buildData();
  const urls = d.gallery;
  const totalPhotos = currentFiles.length + urls.length;
  if(!d.address && !(d.lat && d.lng)){ resultEl.innerHTML = `<div class="result-card">${banner('err','Fyll i en adress (eller lat + lng) innan import.')}</div>`; return; }
  if(!confirm(`Skapa objektet i HV - Databas nu?\n\nAdress: ${d.address||'(lat/lng)'}\nFoton: ${currentFiles.length} filer + ${urls.length} länkar`)) return;

  setBusy(true);
  resultEl.innerHTML = `<div class="result-card"><h3>Importerar…</h3>
    <div class="status-line" id="s-create"><span class="dot run"></span> Skapar objekt (geokod + ort-taggar)</div>
    ${totalPhotos ? '<div class="progressbar"><i id="pbar"></i></div><div id="photolog"></div>' : ''}</div>`;
  try{
    const r = await fetch(`${CFG.fnBase}/${CFG.createFn}`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(d) });
    const j = await r.json();
    if(!r.ok || j.error || !j.item_id){ throw new Error(typeof j.error==='object'?JSON.stringify(j.error):(j.error||('inget item_id (HTTP '+r.status+')'))); }
    const itemId = j.item_id;
    document.getElementById('s-create').innerHTML = `<span class="dot ok"></span> Objekt skapat · <a class="item-link" href="${CFG.itemUrl(itemId)}" target="_blank" rel="noopener">öppna i Monday (id ${esc(itemId)}) →</a>`;

    const log = document.getElementById('photolog');
    let done=0, ok=0, fail=0, idx=0;
    const step = (label)=>{ const line=document.createElement('div'); line.className='status-line'; line.innerHTML=`<span class="dot run"></span> ${label}…`; log.appendChild(line); return line; };
    const bump = (line, good, label)=>{ done++; if(good) ok++; else fail++; line.innerHTML=`<span class="dot ${good?'ok':'err'}"></span> ${label}`; const bar=document.getElementById('pbar'); if(bar) bar.style.width=Math.round(done/totalPhotos*100)+'%'; };
    // Ordningen avgor vilken bild som blir omslagsbild i HV-Databas. Tidigare laddades
    // uppladdade filer ALLTID upp forst, vilket gjorde manuellt tillagda foton till omslag.
    const uploadFiles = async () => {
      for(let k=0;k<currentFiles.length;k++){
        idx++; const line=step(`Bild ${idx}/${totalPhotos} (fil)`);
        try{ const comp=await compressImage(currentFiles[k]);
          // compressImage ger jpeg. Falleras avkodningen (t.ex. en HEIC som heic2any inte
          // klarade) foljer ORIGINALET med - och da ska filnamnet tala om vad det faktiskt
          // ar i stallet for att pasta jpeg. Samma regel som import-photo-url foljer pa
          // serversidan sedan 2026-09-14.
          // Ar typen okand (t.ex. image/heic som heic2any inte klarade) far ORIGINALETS egen
          // filandelse galla. Att falla tillbaka pa "jpg" vore att gora om precis det fel
          // regeln finns for: heic-bytes i en fil som utger sig for att vara jpeg.
          const EXT_AV={'image/jpeg':'jpg','image/jpg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','image/avif':'avif'};
          const egenAndelse=(String(comp.name||'').split('.').pop()||'').toLowerCase();
          const fext=EXT_AV[String(comp.type||'').toLowerCase()]
            || (/^[a-z0-9]{2,5}$/.test(egenAndelse) ? egenAndelse : 'jpg');
          // Egna filer gar till VAR import-photo-url, inte hyresvardformularets
          // upload-landlord-photo. Den senare borjade 2026-09-23 svara med en ogiltig
          // CORS-header (projektets delade ALLOWED_ORIGIN blev en kommalista), sa bilderna kom
          // fram men webblasaren fick inte lasa svaret - varje fil rapporterades som
          // misslyckad. import-photo-url har CORS "*", konverterar till jpeg och doper filen
          // efter "index", precis som for lankade foton.
          const fd=new FormData(); fd.append('item_id',String(itemId)); fd.append('column_id',CFG.columnId); fd.append('index',String(idx)); fd.append('file',comp,`image${idx}.${fext}`);
          const pr=await fetch(`${CFG.fnBase}/${CFG.photoUrlFn}`, {method:'POST', body:fd});
          const pj=await pr.json().catch(()=>({}));
          if(!pr.ok || pj.error) throw new Error(typeof pj.error==='object'?JSON.stringify(pj.error):(pj.error||('HTTP '+pr.status)));
          bump(line,true,`Bild ${idx}/${totalPhotos} (fil) uppladdad`);
        }catch(e){ bump(line,false,`Bild ${idx}/${totalPhotos} (fil) — fel: ${esc(e.message)}`); }
      }
    };
    const uploadUrls = async () => {
      for(let k=0;k<urls.length;k++){
        idx++; const line=step(`Bild ${idx}/${totalPhotos} (länk)`);
        try{ const pr=await fetch(`${CFG.fnBase}/${CFG.photoUrlFn}`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({item_id:itemId, url:urls[k], index:idx, column_id:CFG.columnId})});
          const pj=await pr.json(); if(!pr.ok || pj.error) throw new Error(typeof pj.error==='object'?JSON.stringify(pj.error):(pj.error||('HTTP '+pr.status)));
          bump(line,true,`Bild ${idx}/${totalPhotos} (länk) uppladdad`);
        }catch(e){ bump(line,false,`Bild ${idx}/${totalPhotos} (länk) — fel: ${esc(e.message)}`); }
      }
    };
    const orderSel=document.getElementById('photoOrder');
    if(orderSel && orderSel.value==='files'){ await uploadFiles(); await uploadUrls(); }
    else { await uploadUrls(); await uploadFiles(); }
    const summary = totalPhotos ? `${ok} foton uppladdade${fail?`, ${fail} misslyckades`:''}.` : 'Objektet skapades utan foton.';
    resultEl.querySelector('.result-card').insertAdjacentHTML('beforeend', banner(fail?'err':'ok', `Klart — ${summary}`));
  }catch(e){
    const sc=document.getElementById('s-create'); if(sc) sc.innerHTML=`<span class="dot err"></span> Kunde inte skapa objektet`;
    resultEl.querySelector('.result-card').insertAdjacentHTML('afterbegin', banner('err','Import misslyckades: '+esc(e.message)));
  }finally{ setBusy(false); }
});

document.getElementById('btnClear').addEventListener('click',()=>{
  if(confirm('Rensa allt?')){
    document.getElementById('form').reset(); document.getElementById('aiJson').value='';
    document.getElementById('url').value=''; document.getElementById('aiInstruction').value='';
    document.getElementById('readImages').checked=false;
    utilAll.checked=true; utilDetail.classList.add('hidden');
    document.querySelectorAll('#amenityGrid input').forEach(cb=>cb.checked=false);
    const ps=document.getElementById('parkingSel'); if(ps) ps.value='';
    fieldsFromAmenityUI();
    currentFiles=[]; renderFiles(); updateCount(); resultEl.innerHTML='';
    setReviewVisible(false);
    aiStatus.textContent='';
  }
});
