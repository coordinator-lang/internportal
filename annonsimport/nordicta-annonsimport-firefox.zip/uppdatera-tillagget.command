#!/bin/bash
# Nordicta Annonsimport - uppdaterare for macOS.
# Dubbelklicka filen. Den hamtar senaste versionen fran internportalen och packar upp
# den over den har mappen. Motsvarigheten pa Windows heter Uppdatera-tillagget.bat.

# Hela kroppen ligger i en funktion: bash laser in och tolkar den FARDIGT innan den kors,
# sa att skriptet tryggt kan skriva over sin egen fil under uppdateringen.
main() {

  BASE_URL="${1:-https://coordinator-lang.github.io/internportal/annonsimport}"
  DIR="$(cd "$(dirname "$0")" && pwd)"
  cd "$DIR" || exit 1

  echo ""
  echo "  Nordicta Annonsimport - uppdatering"
  echo "  -----------------------------------"

  if [ ! -f "$DIR/manifest.json" ]; then
    echo "  FEL: hittar ingen manifest.json i:"
    echo "  $DIR"
    echo ""
    echo "  Lagg den har filen i SAMMA mapp som tillagget."
    read -r -p "  Tryck Enter for att stanga"; exit 1
  fi

  # Plocka ut ett varde ur en enkel JSON-fil utan att krava python/jq.
  json_value() { grep -o "\"$2\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$1" | head -1 | sed 's/.*:[[:space:]]*"//; s/"$//'; }

  LOCAL_VERSION="$(json_value "$DIR/manifest.json" version)"
  if grep -q '"service_worker"' "$DIR/manifest.json"; then VARIANT="chrome"; else VARIANT="firefox"; fi
  echo "  Installerad version : $LOCAL_VERSION ($VARIANT)"

  TMP="$(mktemp -d)"
  if ! curl -fsSL --max-time 20 "$BASE_URL/version.json" -o "$TMP/version.json"; then
    echo "  FEL: kunde inte kontakta internportalen."
    rm -rf "$TMP"; read -r -p "  Tryck Enter for att stanga"; exit 1
  fi

  REMOTE_VERSION="$(json_value "$TMP/version.json" version)"
  ZIP_NAME="$(json_value "$TMP/version.json" "$VARIANT")"
  echo "  Senaste version     : $REMOTE_VERSION"
  echo ""

  if [ "$LOCAL_VERSION" = "$REMOTE_VERSION" ]; then
    echo "  Du har redan senaste versionen. Inget att gora."
    rm -rf "$TMP"; read -r -p "  Tryck Enter for att stanga"; exit 0
  fi

  echo "  Hamtar $ZIP_NAME ..."
  if ! curl -fsSL --max-time 120 "$BASE_URL/$ZIP_NAME" -o "$TMP/ext.zip"; then
    echo "  FEL: nedladdningen misslyckades."
    rm -rf "$TMP"; read -r -p "  Tryck Enter for att stanga"; exit 1
  fi

  mkdir -p "$TMP/unpacked"
  if ! unzip -q -o "$TMP/ext.zip" -d "$TMP/unpacked"; then
    echo "  FEL: kunde inte packa upp paketet."
    rm -rf "$TMP"; read -r -p "  Tryck Enter for att stanga"; exit 1
  fi
  if [ ! -f "$TMP/unpacked/manifest.json" ]; then
    echo "  FEL: paketet ser felaktigt ut (ingen manifest.json)."
    rm -rf "$TMP"; read -r -p "  Tryck Enter for att stanga"; exit 1
  fi

  echo "  Packar upp over mappen ..."
  cp -R "$TMP/unpacked/." "$DIR/"
  chmod +x "$DIR/uppdatera-tillagget.command" 2>/dev/null
  # macOS satter karantan-flagga pa nedladdade filer; ta bort den sa nasta korning inte varnar.
  xattr -d com.apple.quarantine "$DIR/uppdatera-tillagget.command" 2>/dev/null
  rm -rf "$TMP"

  echo ""
  echo "  KLART - version $REMOTE_VERSION ar installerad."
  echo ""
  echo "  SISTA STEGET (en gang):"
  if [ "$VARIANT" = "firefox" ]; then
    echo "  Oppna about:debugging#/runtime/this-firefox och klicka 'Las in pa nytt'."
  else
    echo "  Oppna chrome://extensions och klicka reload-ikonen pa Nordicta Annonsimport."
  fi
  echo ""
  read -r -p "  Tryck Enter for att stanga"

}

main "$@"
