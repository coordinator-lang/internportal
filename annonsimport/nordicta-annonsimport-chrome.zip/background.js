// Nordicta Annonsimport – service worker (MV3)
// On toolbar-click: harvest the CURRENT listing page (rendered DOM + every photo URL) inside
// the user's own browser (no server fetch → no Qasa/Airbnb 429), stash it, and open the review
// page. The review page sends the HTML to extract-listing and drives the import.

// Runs in the page context via chrome.scripting — must be fully self-contained (no outer refs).
function harvestPage() {
  const html = document.documentElement.outerHTML;
  const pageUrl = location.href;

  const abs = (u) => { try { return new URL(u, location.href).href; } catch (e) { return null; } };

  // Qasa levererar samma foto via en bildproxy i flera transformer
  // (/unsafe/300x300/smart/… och /unsafe/adaptive-fit-in/1200x1200/…). Normalisera till
  // fullstorleks-varianten REDAN HÄR, annars slipper båda igenom dedupen och backend slår
  // ihop dem först efteråt — vilket fick 13 skördade foton att bli 9 i granskningsvyn.
  const canon = (u) => {
    const t = String(u);
    const p = t.indexOf("img.qasa.se/unsafe/");
    if (p < 0) return t;
    const k = t.indexOf("http", p + "img.qasa.se/unsafe/".length);
    if (k < 0) return t;
    return "https://img.qasa.se/unsafe/adaptive-fit-in/1200x1200/" + t.slice(k);
  };

  // URL-markers that are never listing photos (logos, icons, sprites, maps, ads…).
  // Verifierat mot wg-gesucht: utan "kooperation|partner|sponsor" följde partnerannonser med.
  const BAD = /(sprite|logo|favicon|\bicon|avatar|profile-?pic|placeholder|banner|advert|\bads?\b|pixel|tracking|beacon|\bmap\b|badge|\bflag\b|watermark|kooperation|partner|sponsor|affiliate)/i;

  // Two photos are "the same" if they differ only by a size token in the URL — so a 300px
  // thumbnail and its 1200px original collapse to one entry (we keep the largest variant).
  const idOf = (u) => String(u).split('?')[0]
    .replace(/\/\d{2,4}x\d{2,4}\//g, '/')
    .replace(/[_-]\d{2,4}x\d{2,4}(?=\.[a-z]{3,4}$)/i, '')
    .replace(/[_-](small|medium|large|thumb|thumbnail|orig|original|xs|sm|md|lg|xl)(?=\.[a-z]{3,4}$)/i, '')
    .toLowerCase();

  // Largest candidate out of a srcset ("url 320w, url 1200w" → the 1200w one).
  const bestFromSrcset = (ss) => {
    if (!ss) return null;
    let best = null, bestW = -1;
    String(ss).split(',').forEach((part) => {
      const bits = part.trim().split(/\s+/);
      if (!bits[0]) return;
      const m = (bits[1] || '').match(/^(\d+)w$/);
      const w = m ? parseInt(m[1], 10) : 0;
      if (w > bestW) { bestW = w; best = bits[0]; }
    });
    return best;
  };

  const inChrome = (el) => {
    try {
      return !!el.closest('header, nav, [role="banner"], [role="navigation"], [class*="avatar"], [class*="Avatar"], [class*="logo"], [class*="Logo"]');
    } catch (e) { return false; }
    // NOTE: never add `button` here — Qasa wraps its whole gallery in a clickable button,
    // which once filtered away all 22 real photos (verified 2026-08-11).
  };

  // ── 1) DOM pass: images the page actually renders at photo size ────────────────────
  // Platform-agnostic: works on German portals etc. without site-specific rules.
  const picked = [];           // {url, id, w, h}
  const denyId = {};
  const seenId = {};

  const consider = (rawUrl, el, w, h) => {
    const u = canon(abs(rawUrl) || '');
    if (!u || !/^https?:/i.test(u)) return;
    if (!/\.(jpe?g|png|webp|avif)(\?|$)/i.test(u) && !/\/(image|photo|img|media)/i.test(u)) return;
    const id = idOf(u);
    const small = w > 0 && h > 0 && w <= 80 && h <= 80;
    if (small || BAD.test(u) || (el && inChrome(el))) { denyId[id] = 1; return; }
    // Photo-sized in the layout → treat as a listing photo.
    if (w >= 140 && h >= 100) {
      if (!seenId[id]) { seenId[id] = 1; picked.push({ url: u, id: id, w: w, h: h }); }
    }
  };

  document.querySelectorAll('img').forEach((im) => {
    const r = im.getBoundingClientRect();
    const cand = bestFromSrcset(im.getAttribute('srcset')) || im.currentSrc || im.getAttribute('src')
      || im.getAttribute('data-src') || im.getAttribute('data-original') || im.getAttribute('data-lazy')
      || im.getAttribute('data-srcset');
    if (cand) consider(cand, im, Math.round(r.width), Math.round(r.height));
  });

  // Galleries built from CSS background-image (common on Lodgify/agency sites).
  document.querySelectorAll('div, section, a, li, span').forEach((el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 140 || r.height < 100) return;
    let bg = '';
    try { bg = getComputedStyle(el).backgroundImage || ''; } catch (e) { return; }
    const m = bg.match(/url\(["']?(.*?)["']?\)/i);
    if (m && m[1]) consider(m[1], el, Math.round(r.width), Math.round(r.height));
  });

  // ── 2) Family pass: recover gallery photos not yet rendered (lazy/carousel) ────────
  // Real galleries live under a shared path prefix. Take the prefixes of the confirmed
  // photos, then pull sibling image URLs out of the raw HTML. This generalises the trick
  // that was previously hard-coded for Qasa, so it also works on unknown sites.
  const prefixes = {};
  picked.forEach((p) => {
    const cut = p.url.split('?')[0].lastIndexOf('/');
    if (cut > 8) prefixes[p.url.split('?')[0].slice(0, cut + 1)] = 1;
  });
  const prefixList = Object.keys(prefixes).slice(0, 8);
  if (prefixList.length) {
    const urlRe = /https?:\\?\/\\?\/[^\s"'<>()\\]+?\.(?:jpe?g|png|webp|avif)/gi;
    let m;
    while ((m = urlRe.exec(html))) {
      const u = m[0].replace(/\\\//g, '/');
      if (!prefixList.some((p) => u.indexOf(p) === 0)) continue;
      const id = idOf(u);
      if (denyId[id] || seenId[id] || BAD.test(u)) continue;
      seenId[id] = 1;
      picked.push({ url: u, id: id, w: 0, h: 0 });
    }
  }

  // ── 3) Site-specific boosters (proven, give the FULL gallery even when lazy) ───────
  const add = (u) => { const id = idOf(u); if (!denyId[id] && !seenId[id]) { seenId[id] = 1; picked.unshift({ url: u, id: id, w: 0, h: 0 }); } };
  let mm;
  if (/qasa/i.test(location.hostname)) {
    const reQasa = /\/img\\?\/([a-f0-9]{16,})\.(jpe?g|png|webp)/gi;
    while ((mm = reQasa.exec(html))) {
      const file = (mm[1] + '.' + mm[2]).toLowerCase();
      if (denyId[idOf('https://img.qasa.se/unsafe/adaptive-fit-in/1200x1200/https://qasa-static-prod.s3-eu-west-1.amazonaws.com/img/' + file)]) continue;
      add('https://img.qasa.se/unsafe/adaptive-fit-in/1200x1200/https://qasa-static-prod.s3-eu-west-1.amazonaws.com/img/' + file);
    }
  }
  if (/airbnb/i.test(location.hostname)) {
    const reAir = /https:\/\/a0\.muscache\.com\/im\/pictures\/hosting\/Hosting-\d+\/original\/[^\s"'\\]+?\.(?:jpe?g|png|webp)/gi;
    while ((mm = reAir.exec(html))) add(mm[0]);
  }

  return { html: html, url: pageUrl, photos: picked.map((p) => p.url).slice(0, 100) };
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: harvestPage });
    const data = (res && res.result) || {};
    await chrome.storage.local.set({ handoff: { html: data.html || '', url: data.url || '', photos: data.photos || [], ts: Date.now() } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('review.html') });
  } catch (e) {
    // activeTab isn't granted on restricted pages (chrome://, the Web Store, PDF viewer…).
    await chrome.storage.local.set({ handoff: { error: String(e && e.message || e), ts: Date.now() } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('review.html') });
  }
});
