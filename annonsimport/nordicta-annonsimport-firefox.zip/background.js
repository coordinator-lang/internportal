// Nordicta Annonsimport – service worker (MV3)
// On toolbar-click: harvest the CURRENT listing page (rendered DOM + every photo URL) inside
// the user's own browser (no server fetch → no Qasa/Airbnb 429), stash it, and open the review
// page. The review page sends the HTML to extract-listing and drives the import.

// Runs in the page context via chrome.scripting — must be fully self-contained (no outer refs).
function harvestPage() {
  const html = document.documentElement.outerHTML;
  const pageUrl = location.href;
  // Airbnb-annonsens id star i URL:en (/rooms/<id>) OCH i varje foto-URL (Hosting-<id>/).
  // Sektioner som "Fler boenden i narheten" visar ANDRA annonsers foton - de bar ett annat
  // id och far aldrig folja med. Verifierat: alla 29 foto-URL:er pa /rooms/43473343 bar det id:t.
  const roomId = (function () {
    const p = location.pathname;
    const at = p.indexOf("/rooms/");
    if (at < 0) return "";
    const rest = p.slice(at + 7);
    let out = "";
    for (let c = 0; c < rest.length; c++) {
      const ch = rest.charAt(c);
      if (ch >= "0" && ch <= "9") out += ch; else break;
    }
    return out;
  })();
  // Airbnb skriver samma annons-id pa TVA satt i foto-URL:erna: rent nummer
  // (Hosting-37986438/) och base64 av "StaySupplyListing:<id>"
  // (Hosting-U3RheVN1cHBseUxpc3Rpbmc6Mzc5ODY0Mzg=/). Bada tillhor VAR annons och maste
  // godkannas - annars kastas egna foton bort som om de vore grannannonsens.
  const roomIds = (function () {
    if (!roomId) return [];
    const out = [roomId];
    try { out.push(btoa("StaySupplyListing:" + roomId)); } catch (e) { /* btoa saknas */ }
    return out;
  })();
  const ownHosting = (u) => roomIds.some((id) => u.indexOf("Hosting-" + id + "/") >= 0);

  // Vissa sajter bakar in bild-URL:er i JSON dar snedstrecken ar escapade. Av-escapa EN gang
  // har, sa slipper alla regexar nedan hantera det (och slipper dubbla backslash).
  const BSLASH = String.fromCharCode(92);
  const flat = html.split(BSLASH + '/').join('/').split('&amp;').join('&');

  const abs = (u) => { try { return new URL(u, location.href).href; } catch (e) { return null; } };

  // Qasa levererar samma foto via en bildproxy i flera transformer. Normalisera till
  // fullstorleks-varianten redan har, annars slipper bada igenom dedupen.
  // Bildproxyer (wsrv.nl, images.weserv.nl m.fl.) lindar den riktiga bilden i ?url=<kodad>.
  // Packa upp den: ger ratt filandelse (proxy-URL:en saknar den), originalkvalitet, och slar
  // ihop alla breddvarianter till ETT foto. Verifierat pa kotimaailma.com dar fotona annars
  // sallades bort helt - 72 proxy-URL:er blev 26 unika efter uppackning.
  const unwrapProxy = (u) => {
    const t = String(u);
    const q = t.indexOf("?url=");
    if (q < 0) return t;
    let inner = t.slice(q + 5);
    const amp = inner.indexOf("&");
    if (amp >= 0) inner = inner.slice(0, amp);
    try { inner = decodeURIComponent(inner); } catch (e) { return t; }
    return inner.indexOf("http") === 0 ? inner : t;
  };

  // Storsta varianten vinner nar samma foto finns i flera storlekar (-900-600- vs -300-200-).
  const isNum = (x) => x.length >= 2 && x.length <= 4 && String(parseInt(x, 10)) === x;
  const widthHint = (u) => {
    const seg = String(u).split("?")[0].split("/").pop();
    const parts = seg.split("-");
    for (let i = 0; i + 1 < parts.length; i++) {
      if (isNum(parts[i]) && isNum(parts[i + 1])) return parseInt(parts[i], 10);
    }
    // "foto-1024x683.jpg" - sa skriver WordPress och en mangd andra CMS:er sina varianter.
    // idOf() stadar redan bort det ur identiteten, men widthHint gav 0 for BADA, sa nar tva
    // varianter motte varandra vann den forst sedda - inte sallan miniatyren pa 150x150.
    const bitar = seg.split(".")[0].split("_").join("-").split("-");
    for (let i = 0; i < bitar.length; i++) {
      const xk = bitar[i].indexOf("x");
      if (xk <= 0) continue;
      const bred = bitar[i].slice(0, xk), hojd = bitar[i].slice(xk + 1);
      if (isNum(bred) && isNum(hojd)) return parseInt(bred, 10);
    }
    // Webflow: "<namn>-p-1600.webp". Webflow driver en stor mangd sajter, sa det monstret
    // moter vi om och om igen - bleisured.com var det forsta (rapporterat 2026-09-21).
    for (let i = 0; i + 1 < bitar.length; i++) {
      if (bitar[i] === "p" && isNum(bitar[i + 1])) return parseInt(bitar[i + 1], 10);
    }
    return 0;
  };

  // Namngiven storlek i filnamnet: "03_small.jpg" / "03_large.jpg". idOf() stadar redan bort
  // just de orden, sa varianterna raknas som ETT foto - men tiebreakern var widthHint(), som
  // bara laser "-<bredd>-<hojd>-" och ger 0 for bada. Da vann den FORST sedda, alltsa
  // miniatyren. Matt pa novecentocase.com (rapporterat 2026-09-11): _small 720x480 (156 KB)
  // mot _large 1620x1080 (644 KB).
  // Listan maste vara samma ord som idOf() stadar bort - annars kan tva URL:er ha olika
  // identitet och jamforelsen intraffar aldrig. Ordningen ar liten -> stor.
  const SIZE_WORDS = ["thumb", "thumbnail", "xs", "sm", "small", "md", "medium", "lg", "large", "xl", "orig", "original"];
  // Beskrivningen kan vara FLERDELAD. skyhotelapartments.se (vander) serverar varje foto som
  // -thumbnail / -extra-small / -small / -small-500 / -medium / -large / -extra-large, och
  // en regel som bara laste sista ordet gjorde "extra-large" till "large" och "small-500"
  // till ingenting alls. Ordet avgor trappsteget; ett avslutande rent tal ar en pixelbredd
  // som bara skiljer varianter med SAMMA ord at, sa det vager lattare.
  const sizeRank = (u) => {
    const seg = String(u).split("?")[0].split("/").pop();
    const dot = seg.lastIndexOf(".");
    if (dot < 1) return 0;
    const bitar = seg.slice(0, dot).toLowerCase().split("_").join("-").split("-");
    if (bitar.length < 2) return 0;
    let tal = 0;
    if (isNum(bitar[bitar.length - 1])) {
      tal = parseInt(bitar[bitar.length - 1], 10);
      bitar.pop();
      if (bitar.length < 2) return 0;
    }
    const ord = bitar[bitar.length - 1];
    const at = SIZE_WORDS.indexOf(ord);
    if (at < 0) return 0;              // 0 = ingen storlek utlast (t.ex. en uuid)
    let steg = at + 1;
    // "extra-large"/"x-large" ligger ett halvt steg over "large" - och "extra-small" lika
    // mycket under "small". Samma trappa som CSS-storlekarna.
    const fore = bitar.length > 1 ? bitar[bitar.length - 2] : "";
    if (fore === "extra" || fore === "x") steg += (ord === "small" || ord === "xs") ? -0.5 : 0.5;
    return steg * 1000 + tal;
  };

  // Storre variant av SAMMA foto vinner. Uppmatta pixeltal i URL:en gar fore namngiven
  // storlek, sa sajter som bar riktiga tal (kotimaailma: -900-600-) beter sig exakt som forr.
  // Namnen jamfors bara nar BADA ar utlasta: "x.jpg" mot "x_small.jpg" sager ingenting om
  // vilken som ar storst, och da ska det gamla beteendet galla (den forst sedda behalls).
  const bigger = (a, b) => {
    const wa = widthHint(a), wb = widthHint(b);
    // Ett PIXELTAL i filnamnet betyder att adressen ar en framstalld variant: nagon har
    // renderat originalet i just den bredden. Saknar den andra adressen ett sadant tal ar
    // den originalet - och originalet ar storst. Uppmatt pa bleisured.com (Webflow):
    // originalet 318 KB mot 198 KB for "-p-1600". Samma forhallande pa WordPress
    // ("hus.jpg" mot "hus-1024x683.jpg").
    // Detta galler BARA pixeltal. Ett storleksORD ("x.jpg" mot "x_small.jpg") sager
    // fortfarande ingenting om vilken som ar storst - den slutsatsen drogs medvetet
    // 2026-09-11 och star kvar; da behalls den forst sedda.
    // bigger() anropas aldrig pa tva OLIKA foton, bara pa varianter av samma.
    if ((wa > 0) !== (wb > 0)) return wa === 0;
    if (wa !== wb) return wa > wb;
    const ra = sizeRank(a), rb = sizeRank(b);
    return ra > 0 && rb > 0 && ra > rb;
  };

  // Airbnb serverar samma foto i flera bredder via ?im_w=. Sidan renderar 720/960 px medan
  // samma URL UTAN query ger originalet. Matt pa /im/pictures/252f57e8-...jpg:
  // im_w=720 -> 51 KB, im_w=1440 -> 155 KB, utan query -> 234 KB. Strippa darfor querysen:
  // det ger originalet OCH lar alla breddvarianter av samma foto falla ihop till ETT.
  const fullSize = (u) => {
    const t = String(u);
    if (t.indexOf("muscache.com") < 0) return t;
    const q = t.indexOf("?");
    return q < 0 ? t : t.slice(0, q);
  };

  const canon = (u) => {
    const t = fullSize(unwrapProxy(String(u)));
    const p = t.indexOf("img.qasa.se/unsafe/");
    if (p < 0) return t;
    const k = t.indexOf("http", p + "img.qasa.se/unsafe/".length);
    if (k < 0) return t;
    return "https://img.qasa.se/unsafe/adaptive-fit-in/1200x1200/" + t.slice(k);
  };

  // Aldrig annonsfoton: logotyper, ikoner, kartor, annonser - och appens EGNA statiska filer
  // (Next.js /_next/static/, /static/media/). Verifierat pa homeq.se, dar en partnerlogga
  // annars blev enda "fotot", och pa wg-gesucht (partnerannonser).
  const BAD = /(sprite|logo|favicon|\bicon|avatar|profile-?pic|placeholder|banner|advert|\bads?\b|pixel|tracking|beacon|\bmaps?\b|openstreetmap|mapbox|maptiler|basemap|\/geo\/|_next\/static|\/static\/media\/|badge|\bflag\b|watermark|kooperation|partner|sponsor|affiliate)/i;

  // Identitet for dedup: strippa storleks-tokens OCH rena siffer-mappar, sa att
  // /1440/apartment_images/X.jpg och /apartment_images/X.jpg raknas som samma foto.
  // Tar bort "-<bredd>-<hojd>-" ur filnamnet (kotimaailma: 11326-900-600-... = 11326-300-200-...).
  const stripSizePair = (s) => {
    const parts = s.split("-");
    const out = [];
    for (let i = 0; i < parts.length; i++) {
      if (i + 1 < parts.length && isNum(parts[i]) && isNum(parts[i + 1])) { i++; continue; }
      out.push(parts[i]);
    }
    return out.join("-");
  };
  const idOf = (u) => stripSizePair(String(u).split('?')[0])
    .replace(/\/\d{2,4}x\d{2,4}\//g, '/')
    .replace(/\/\d{2,4}\//g, '/')
    .replace(/[_-]\d{2,4}x\d{2,4}(?=\.[a-z]{3,4}$)/i, '')
    .replace(/[_-]p-\d{2,5}(?=\.[a-z]{3,4}$)/i, '')
    .replace(/[_-](?:extra-|x-)?(?:thumbnail|thumb|small|medium|large|original|orig|xs|sm|md|lg|xl)(?:-\d{2,4})?(?=\.[a-z]{3,4}$)/i, '')
    .toLowerCase();

  // En srcset separerar kandidater med komma + blanksteg. Sjalva ADRESSEN kan innehalla
  // komman: vuokraovi lagger bildtransformen i sokvagen ("/1300x900,fit,q80,f=webp/...").
  // Ett rakt split(",") slog darfor sonder adressen, och sista biten - den som bar
  // bredd-markoren - blev "f=webp/etuovimedia/..." som tolkades som en RELATIV lank och
  // pekade ut sidans egen sokvag. Resultat: sex trasiga rutor i granskningsvyn
  // (rapporterat 2026-09-09). Dela darfor bara pa komman som foljs av blanksteg eller av
  // borjan pa en ny adress.
  const bestFromSrcset = (ss) => {
    if (!ss) return null;
    let best = null, bestW = -1;
    String(ss).split(/,(?=\s|https?:\/\/|\/\/)/).forEach((part) => {
      const bits = part.trim().split(/\s+/);
      if (!bits[0]) return;
      // Markoren ar antingen bredd ("1200w") eller tathet ("2x"). HTML tillater inte bada i
      // samma srcset, sa ett enda tal racker for att jamfora inom listan. Forr lastes bara
      // "w" - vid "1x, 2x" vann alltsa FORSTA kandidaten, alltsa den lagupplosta.
      const d = bits[1] || '';
      const mw = d.match(/^(\d+)w$/);
      const mx = d.match(/^([0-9.]+)x$/);
      const w = mw ? parseInt(mw[1], 10) : (mx ? parseFloat(mx[1]) : 0);
      if (w > bestW) { bestW = w; best = bits[0]; }
    });
    return best;
  };

  // <body> och <html> raknas ALDRIG som sajtens ytor. WordPress satter sjalv klassen
  // "wp-custom-logo" pa <body> sa snart sajten valt en egen logga - och eftersom
  // [class*="logo"] matchar pa en DELstrang, och <body> omsluter allt, blev VARJE bild pa
  // sidan "sajtens logga". Hela skorden gav noll foton (lastapartment.it, 2026-09-28), och
  // likadant pa varje WordPress-sajt med egen logga. Bara element UNDER body far avgora.
  const inChrome = (el) => {
    try {
      // "offcanvas" ar Bootstraps utfallbara meny - alltsa navigering, inte galleri.
      // thebestrent lagger en 758x758-grafik dar; den passerade storleksfiltret och drog
      // dessutom med sig en systerbild ur /contents/ via familje-svepet (32 i stallet for 30).
      const m = el.closest('header, nav, [role="banner"], [role="navigation"], [class*="avatar"], [class*="Avatar"], [class*="logo"], [class*="Logo"], [class*="offcanvas"], [class*="Offcanvas"]');
      return !!m && m !== document.body && m !== document.documentElement;
    } catch (e) { return false; }
    // NOTE: aldrig `button` har - Qasa lindar hela galleriet i en klickbar knapp.
  };

  const picked = [];
  const denyId = {};
  const seenId = {};
  const idxOf = {};

  // w/h = hur stor bilden ar i layouten, nw/nh = sjalva bildfilens storlek.
  const consider = (rawUrl, el, w, h, nw, nh, viaLank) => {
    const u = canon(abs(rawUrl) || '');
    if (!u || !/^https?:/i.test(u)) return;
    if (!/\.(jpe?g|png|webp|avif)(\?|$)/i.test(u) && !/\/(image|photo|img|media)/i.test(u)) return;
    const id = idOf(u);
    const small = w > 0 && h > 0 && w <= 80 && h <= 80;
    if (small || BAD.test(u) || (el && inChrome(el))) { denyId[id] = 1; return; }
    // Foto fran en ANNAN Airbnb-annons (t.ex. "Fler boenden i narheten").
    if (roomId && u.indexOf("muscache.com") > 0 && u.indexOf("Hosting-") > 0
        && !ownHosting(u)) { denyId[id] = 1; return; }
    // Utlagd i fotostorlek ELLER en stor bildfil som bara inte ar utlagd just nu. Det andra
    // kravs for karuseller/slides (homeq.se renderar dolda slides med bredd 0).
    const renderedBig = w >= 140 && h >= 100;
    const fileBig = nw >= 500 && nh >= 350;
    // viaLank = sidan lankar SJALV den har bilden till en annan, storre bildfil (lightbox).
    // Da ar det ett gallerifoto, hur liten miniatyren an rakar vara. Utan det undantaget foll
    // hela thebestrent.it bort: dess miniatyrer ar 400x400 kvadratiska beskarningar renderade
    // i 105x109 - under BADA matten - fast lanken pekar pa 1310x875. Trettio foton blev noll.
    // Spararna ovanfor galler fortfarande: BAD-listan, header/nav-containrar och 80x80-regeln
    // stoppar en ikon eller logotyp aven om den rakar vara lankad till en bildfil.
    if (renderedBig || fileBig || viaLank) {
      if (!seenId[id]) {
        seenId[id] = 1; idxOf[id] = picked.length; picked.push({ url: u, id: id, lank: !!viaLank });
      } else if (idxOf[id] !== undefined && bigger(u, picked[idxOf[id]].url)) {
        picked[idxOf[id]].url = u;   // samma foto, storre variant
        picked[idxOf[id]].lank = !!viaLank;
      }
    }
  };

  // LIGHTBOX-LANKEN. Ett vanligt galleri visar MINIATYREN i <img> och lagger fullstorleken i
  // <a href> runt den (magnific-popup, fancybox, lightbox, photoswipe, WordPress "lank till
  // mediafil"). Miniatyren ar da det enda DOM-svepet ser. Fullstorleken finns i sidkoden fran
  // borjan, sa galleriet behover ALDRIG oppnas - koord hade inte oppnat det heller.
  // Rapporterat 2026-09-11 pa novecentocase.com: 9 av 10 foton importerades i 720x480 fast
  // 1620x1080 lag i lanken.
  //
  // Tre sparrar gor att detta inte kan dra in nagot nytt:
  //  1. Bara samma foto - lanken maste peka pa samma identitet enligt idOf() ELLER pa samma
  //     FILNAMN (se motiveringen vid jamforelsen nedan). En ANNAN bild (grannannons, karta,
  //     maklarlogga) heter nagot annat och passerar darfor ingen av de tva.
  //  2. Bara bildlankar - <a href> till en annonssida eller pdf lamnas i fred. Det ar ocksa
  //     varfor Qasa och Airbnb inte beros: dar gar lanken till /listings/<id> resp /rooms/<id>.
  //  3. Adressen kommer fran sidan sjalv och finns darfor garanterat - vi gissar inga suffix.
  // Vi byter INTE om miniatyren bevisligen ar storst (bigger sager det) - annars vinner
  // lanken, for i ett lightbox-galleri ar den per definition fullvyn.
  const PHOTO_EXT = ["jpg", "jpeg", "png", "webp", "avif"];
  const filnamnAv = (u) => String(u).split("?")[0].split("/").pop().toLowerCase();
  // Returnerar ALLTID en absolut adress, sa anroparen kan jamfora och se om lanken vann.
  const fromLightbox = (im, cand) => {
    const c = abs(cand) || "";
    let a = null;
    try { a = im.closest("a"); } catch (e) { return c || cand; }
    if (!a || !c) return c || cand;
    const href = abs(a.getAttribute("href") || "");
    if (!href) return c;
    const base = href.split("?")[0].toLowerCase();
    const dot = base.lastIndexOf(".");
    if (dot < 0 || PHOTO_EXT.indexOf(base.slice(dot + 1)) < 0) return c;
    // Samma foto? Antingen samma identitet (novecentocase: 03_small.jpg mot 03_large.jpg)
    // ELLER samma filnamn i en annan mapp. Det senare behovs for storleksmappar som idOf()
    // inte stadar bort: thebestrent lagger varianterna i ENSIFFRIGA mappar
    // (/images/8/251/<id>.webp mot /images/3/251/<id>.webp), och idOf() stryker bara mappar
    // med 2-4 siffror. Lanken sitter runt sjalva bilden, sa samma filnamn racker som bevis.
    if (idOf(href) !== idOf(c) && filnamnAv(href) !== filnamnAv(c)) return c;
    return bigger(c, href) ? c : href;
  };

  document.querySelectorAll('img').forEach((im) => {
    const r = im.getBoundingClientRect();
    const cand = bestFromSrcset(im.getAttribute('srcset')) || im.currentSrc || im.getAttribute('src')
      || im.getAttribute('data-src') || im.getAttribute('data-original') || im.getAttribute('data-lazy')
      || im.getAttribute('data-srcset');
    if (!cand) return;
    const cAbs = abs(cand) || cand;
    const bast = fromLightbox(im, cand);
    consider(bast, im, Math.round(r.width), Math.round(r.height),
      im.naturalWidth || 0, im.naturalHeight || 0, bast !== cAbs);
  });

  // Gallerier byggda pa CSS background-image.
  document.querySelectorAll('div, section, a, li, span').forEach((el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 140 || r.height < 100) return;
    let bg = '';
    try { bg = getComputedStyle(el).backgroundImage || ''; } catch (e) { return; }
    const m = bg.match(/url\(["']?(.*?)["']?\)/i);
    if (m && m[1]) consider(m[1], el, Math.round(r.width), Math.round(r.height), 0, 0);
  });

  // Familje-svep: hamta syskonbilder ur rakoden utifran de bekraftade fotonas sokvag.
  // Jamforelsen sker pa NORMALISERAD form, sa /1440/... matchar /... (homeq.se).
  const prefixes = {};
  picked.forEach((p) => {
    const n = idOf(p.url);
    const cut = n.lastIndexOf('/');
    if (cut > 8) prefixes[n.slice(0, cut + 1)] = 1;
  });
  const prefixList = Object.keys(prefixes).slice(0, 8);
  if (prefixList.length) {
    const urlRe = /https?:\/\/[^\s"'<>()]+?\.(?:jpe?g|png|webp|avif)/gi;
    let m;
    while ((m = urlRe.exec(flat))) {
      const u = m[0];
      const id = idOf(u);
      if (!prefixList.some((p) => id.indexOf(p) === 0)) continue;
      if (denyId[id] || seenId[id] || BAD.test(u)) continue;
      seenId[id] = 1;
      picked.push({ url: u, id: id });
    }
  }

  // NEXT.JS-SIDOR: hela galleriet ligger i sidans egen JSON, inte i DOM:en.
  // Rapporterat 2026-09-14 pa spacest.com/it/rent-listing/103256: importen fick TVA foton av
  // trettioen - och det ena var grannannonsens omslagsbild.
  //
  // Varfor sa fa: karusellen ar lazy-laddad och varje <img> ar en 1x1-gif tills den rullas
  // fram, sa bade renderad storlek och filstorlek faller under filtren. Familje-svepet
  // raddar inget heller: varje foto ligger i en EGEN hash-mapp
  // (/listing/aa/bc/c7/73/<uuid>.jpeg), precis som pa idealista, sa prefixet som byggs ur en
  // bekraftad bild matchar bara just den bilden.
  //
  // Men sidan bar sanningen sjalv: <script id="__NEXT_DATA__"> innehaller annonsens galleri
  // (31 poster a 1800x1200) OCH grannannonsernas galleri, i skilda grenar. Leta darfor upp
  // arrayer dar VARJE post ar en bild-URL (strang, eller objekt med "url"), hoppa over
  // grenar vars nyckel later som "related/similar/nearby/...", och valj den storsta.
  //
  // TVA sparrar, sa detta aldrig kan forsamra en sajt som fungerar:
  //  1. Sajter med EGEN booster (qasa, airbnb, idealista, oikotie, vuokraovi/etuovi) rors
  //     aldrig - deras skord ar handmatt och verifierad, och ska inte kunna overkoras av en
  //     generell gissning.
  //  2. Galleriet maste innehalla minst ETT foto vi redan bekraftat ur DOM:en. Da vet vi att
  //     arrayen hor till DEN HAR annonsen och inte till en grannannons eller en bloggpuff.
  //     Enda undantaget ar nar DOM-svepet gav NOLL foton - da ar vilket galleri som helst
  //     battre an ingenting.
  const egenBooster = /qasa|airbnb|idealista\.|oikotie\.|vuokraovi\.|etuovi\./i.test(location.hostname);
  if (!egenBooster) {
    const nextGalleri = (function () {
      let rot = null;
      try {
        const el = document.getElementById("__NEXT_DATA__");
        if (!el) return null;
        rot = JSON.parse(el.textContent || "null");
      } catch (e) { return null; }
      if (!rot || typeof rot !== "object") return null;
      const SKIP = ["related", "similar", "nearby", "recommend", "suggest", "other", "carousel"];
      const urlAv = (x) => {
        if (typeof x === "string") return x;
        if (x && typeof x === "object" && typeof x.url === "string") return x.url;
        return "";
      };
      const arFoto = (u) => {
        if (!u || u.indexOf("http") !== 0) return false;
        const b = u.split("?")[0].toLowerCase();
        const d = b.lastIndexOf(".");
        return d > 0 && PHOTO_EXT.indexOf(b.slice(d + 1)) >= 0 && !BAD.test(u);
      };
      // Miniatyren kan vara en HELT ANNAN fil, inte ett omdopt namn: pa spacest ar
      // gallery[0].url "aabcc773-...jpeg" medan gallery[0].thumbnailUrl ar
      // "49900c7a-...jpeg" i en annan mapp. Renderar en sajts karusell miniatyrerna skulle
      // overlapp-provet nedan darfor missa, och regeln tyst utebli. Samla darfor postens
      // OVRIGA bild-falt som BEVIS - de avgor bara om arrayen hor till den har annonsen,
      // aldrig vad som importeras (det ar alltid "url").
      const bevisAv = (arr) => {
        const ut = [];
        arr.forEach((x) => {
          if (!x || typeof x !== "object") return;
          Object.keys(x).forEach((k) => {
            if (k === "url") return;
            const v = x[k];
            if (typeof v === "string" && arFoto(v)) ut.push(v);
          });
        });
        return ut;
      };
      const funna = [];
      const ga = (o, skippad, djup) => {
        if (!o || typeof o !== "object" || djup > 14 || funna.length > 40) return;
        if (Array.isArray(o)) { o.forEach((v) => ga(v, skippad, djup + 1)); return; }
        Object.keys(o).forEach((k) => {
          const v = o[k];
          const lagt = k.toLowerCase();
          const nuSkippad = skippad || SKIP.some((s) => lagt.indexOf(s) >= 0);
          if (!nuSkippad && Array.isArray(v) && v.length >= 3) {
            const urls = v.map(urlAv);
            if (urls.every(arFoto)) funna.push({ urls: urls, bevis: urls.concat(bevisAv(v)) });
          }
          ga(v, nuSkippad, djup + 1);
        });
      };
      ga(rot, false, 0);
      if (!funna.length) return null;
      funna.sort((a, b) => b.urls.length - a.urls.length);
      const redan = {};
      picked.forEach((p) => { redan[p.id] = 1; });
      for (let i = 0; i < funna.length; i++) {
        if (funna[i].bevis.some((u) => redan[idOf(u)])) return funna[i].urls;
      }
      return picked.length === 0 ? funna[0].urls : null;
    })();
    if (nextGalleri && nextGalleri.length) {
      const seenN = {};
      const rena = [];
      nextGalleri.forEach((u) => {
        const a = abs(u);
        if (!a) return;
        const id = idOf(a);
        if (seenN[id]) return;
        seenN[id] = 1;
        rena.push({ url: a, id: id });
      });
      if (rena.length) {
        picked.length = 0;
        rena.forEach((p) => picked.push(p));
      }
    }
  }

  // idealista (.pt/.es/.it): TVA saker gjorde att nastan inga foton kom med.
  // 1. Karusellen laddar bara nagra bilder - resten ar tomma <img> (0x0), sa DOM-svepet
  //    ser en handfull av 42.
  // 2. Familje-svepet raddar oss inte, for varje foto ligger i en EGEN hash-mapp
  //    (/b8/f0/b1/). Monstret som byggs ur en bekraftad bilds sokvag matchar da bara
  //    just den bilden.
  // Skorda darfor direkt ur rakoden. Varje foto finns dessutom i flera storlekar:
  // matt pa /imovel/35260653/ ar WEB_DETAIL 1500x2000 px (252 KB), WEB_DETAIL-XL-P
  // 1125x1500 (168 KB) och -L-P 638x850 (64 KB). XXL svarar 404 och utan transform 403,
  // sa WEB_DETAIL ar den storsta som finns. Normalisera dit - da faller de 142 URL:erna
  // i sidkoden ihop till annonsens 42 foton, i basta upplosning.
  if (/idealista\./i.test(location.hostname)) {
    const seenIde = {};
    const ideal = [];
    let p = 0;
    while (true) {
      const at = flat.indexOf("/blur/", p);
      if (at < 0) break;
      p = at + 6;
      // Klipp ut hela URL:en runt traffen.
      let a = at;
      while (a > 0 && '"\'( <>'.indexOf(flat.charAt(a - 1)) < 0) a--;
      let b = at;
      while (b < flat.length && '"\'( <>)'.indexOf(flat.charAt(b)) < 0) b++;
      const u = flat.slice(a, b);
      if (u.indexOf("idealista.") < 0) continue;
      if (!/\.(jpe?g|png|webp)$/i.test(u.split("?")[0])) continue;
      // .../blur/<TRANSFORM>/0/id.pro.<land>.image.master/<hash>/<hash>/<hash>/<id>.jpg
      const bl = u.indexOf("/blur/");
      const md = u.indexOf("/id.", bl);
      if (md < 0) continue;
      const master = u.slice(md + 1).split("?")[0];
      // Varje foto finns i BADE .jpg och .webp - filandelsen far darfor inte inga i
      // identiteten (annars blir annonsens 42 foton 88). Matt pa fyra av dem: bada
      // formaten finns alltid, och jpg ar genomgaende storst (324 KB mot webp:s 216),
      // sa jpg vinner nar bada dyker upp.
      const dot = master.lastIndexOf(".");
      const key = dot > 0 ? master.slice(0, dot) : master;
      const url = u.slice(0, bl) + "/blur/WEB_DETAIL/0/" + master;
      const isJpg = /\.jpe?g$/i.test(master);
      if (seenIde[key] === undefined) {
        seenIde[key] = ideal.length;
        ideal.push(url);
      } else if (isJpg && !/\.jpe?g$/i.test(ideal[seenIde[key]])) {
        ideal[seenIde[key]] = url;   // samma foto, battre format
      }
    }
    // Rakoden ar den fullstandiga sanningen har - den innehaller hela galleriet och
    // varken maklarens profilbild eller sajtens ikoner (de ligger pa st3.idealista.pt
    // utan /blur/). Ersatt darfor DOM-skorden helt, men bara om vi faktiskt hittade nagot.
    if (ideal.length) {
      picked.length = 0;
      ideal.forEach((u) => picked.push({ url: u, id: idOf(u) }));
    }
  }

  // oikotie.fi (finska annonser): DOM-svepet fick noll foton - karusellen ar lazy-laddad och
  // varje foto ligger bakom en SIGNERAD Thumbor-URL:
  //   cdn.asunnot.oikotie.fi/<hmac>=/fit-in/1920x3840/filters:watermark(...)/ot-real-estate-
  //   mediabank-prod/<mapp>/<mapp>/source/<id>
  // Tre saker gor den har sajten speciell, alla uppmatta pa /vuokra-asunnot/inkoo/24680221:
  //
  // 1. SIGNATUREN LASER ALLT. Skriver man om storleken, tar bort filtren eller provar
  //    /unsafe/ svarar CDN:en 400. Vi kan alltsa inte bygga egna URL:er som for Qasa och
  //    idealista - bara valja den storsta variant som REDAN star i sidan (1920 px har).
  // 2. VATTENSTAMPELN SKILJER AGNARNA FRAN VETET. Annonsens egna foton renderas med
  //    filters:watermark(...oikotie-watermark.png...). Korten under "liknande objekt" saknar
  //    det (och kor quality(60) i stallet for 75). Utan den kontrollen foljde tre bilder fran
  //    ANDRA bostader med - kontrollerat genom att oppna dem: ett slitet kok, en tom hall och
  //    ett vitt kok, inget av dem i den har annonsen.
  // 3. URL:en innehaller BADE parenteser och kommatecken (watermark-filtret:
  //    "...png,24,-24,0"), sa varken ( ) eller , far anvandas som URL-grans. Ett avslutande
  //    komma trimmas dock bort - det kommer fran srcset.
  if (/oikotie\./i.test(location.hostname)) {
    const CDN = "cdn.asunnot.oikotie.fi";
    const MB = "mediabank-prod/";
    const STOP = [String.fromCharCode(34), "'", " ", "<", ">", String.fromCharCode(92)];
    const bast = {};
    let p = 0;
    while (true) {
      const at = flat.indexOf(CDN, p);
      if (at < 0) break;
      p = at + CDN.length;
      let a = at;
      while (a > 0 && STOP.indexOf(flat.charAt(a - 1)) < 0) a--;
      let b = at;
      while (b < flat.length && STOP.indexOf(flat.charAt(b)) < 0) b++;
      let u = flat.slice(a, b);
      while (u.length && (u.charAt(u.length - 1) === "," || u.charAt(u.length - 1) === ";")) u = u.slice(0, -1);
      if (u.indexOf("http") !== 0) continue;
      if (u.indexOf("watermark") < 0) continue;      // liknande objekt + maklarlogotyper
      const k = u.lastIndexOf(MB);                   // lastIndexOf: watermark-URL:en ligger fore
      if (k < 0) continue;
      const master = u.slice(k + MB.length);
      // Bredden star i transformen: .../fit-in/<bredd>x<hojd>/
      const f = u.indexOf("fit-in/");
      let w = 0;
      if (f >= 0) {
        let i2 = f + 7, siffror = "";
        while (i2 < u.length && u.charAt(i2) >= "0" && u.charAt(i2) <= "9") { siffror += u.charAt(i2); i2++; }
        w = siffror ? parseInt(siffror, 10) : 0;
      }
      if (!bast[master] || w > bast[master].w) bast[master] = { w: w, url: u };
    }
    const oiko = Object.keys(bast).map((m) => bast[m].url);
    // Bara om vi faktiskt hittade annonsens galleri - annars behall DOM-skorden.
    if (oiko.length) {
      picked.length = 0;
      oiko.forEach((u) => picked.push({ url: u, id: idOf(u) }));
    }
  }

  // vuokraovi.com / etuovi.com: fotona ligger pa en CloudFront-CDN dar transformen ar en egen
  // sokvagsdel:  <host>/<bredd>x<hojd>,fit,q<N>[,f=webp]/etuovimedia/images/rental/import/
  //              <a>/<b>/<hash>/<hash>/ORIGINAL.jpeg
  // Transformen ar OSIGNERAD - vi kan alltsa be om vilken storlek vi vill. Matt pa
  // /kohde/ge3687: sidan renderar 1300x866 webp (34 KB), medan 2470x1710,fit,q95 ger
  // originalet 2048x1365 som jpeg (295 KB). "fit" skalar aldrig upp - 4000x3000 gav exakt
  // samma fil - sa siffrorna ar ett tak, inte en begaran om uppforstoring. Utan transform
  // svarar CDN:en 403.
  //
  // Sidan visar ocksa "liknande objekt" fran ANDRA annonser. De ligger i egna
  // /import/<a>/<b>/-mappar och renderas smatt (320x). Annonsens EGEN mapp ar den som har den
  // storsta transformen - det ar den som visas i galleriet. Matt pa samma sida: egen mapp 13
  // foton i upp till 2470 px, grannannonserna 1 foto i 320 px.
  if (/vuokraovi\.|etuovi\./i.test(location.hostname)) {
    const MARK = "/etuovimedia/";
    const STOPV = [String.fromCharCode(34), "'", " ", "<", ">", String.fromCharCode(92)];
    const funna = [];
    let vp = 0;
    while (true) {
      const at = flat.indexOf(MARK, vp);
      if (at < 0) break;
      vp = at + MARK.length;
      let a = at;
      while (a > 0 && STOPV.indexOf(flat.charAt(a - 1)) < 0) a--;
      let b = at;
      while (b < flat.length && STOPV.indexOf(flat.charAt(b)) < 0) b++;
      const u = flat.slice(a, b);
      // OBS: hoppa INTE over sidans mall-URL:er. Sidan bar varje foto som
      // "//host/{imageParameters}/etuovimedia/..." i sin JSON och satter in transformen
      // forst nar bilden renderas - sa de flesta foton FINNS bara i mallform. Matt pa
      // /kohde/ge3687: 13 foton i mappen, men bara 3 med konkret transform (de renderade).
      // Mallen ar alltsa precis det vi vill ha: vi satter var egen transform i stallet.
      const cut = u.indexOf(MARK);
      const vard = u.slice(0, cut);               // <proto>//<host>/<transform>
      const master = u.slice(cut + 1);            // etuovimedia/images/rental/import/...
      const slash = vard.lastIndexOf("/");
      if (slash <= 0) continue;
      const host = vard.slice(0, slash);
      const transform = vard.slice(slash + 1);
      // Bredden ur transformen ("1300x900,fit,q80" -> 1300). Mall-URL:er saknar den och far
      // 0 - de rostar alltsa inte om vilken mapp som ar annonsens egen.
      let w = 0;
      const xk = transform.indexOf("x");
      if (xk > 0) {
        const tal = transform.slice(0, xk);
        if (String(parseInt(tal, 10)) === tal) w = parseInt(tal, 10);
      }
      // Annonsmappen: /import/<a>/<b>/
      let mapp = "";
      const ik = master.indexOf("/import/");
      if (ik >= 0) {
        const delar = master.slice(ik + 8).split("/");
        if (delar.length >= 2) mapp = delar[0] + "/" + delar[1];
      }
      if (!mapp) continue;
      funna.push({ host: host, master: master, w: w, mapp: mapp });
    }
    // Vilken mapp ar annonsens egen? Den som renderas STORST - galleriet visas i full
    // bredd medan "liknande objekt" ligger i 320 px. Har ingen mapp nagon renderad bild
    // (allt i mallform) avgor ANTALET i stallet: annonsens egen har flest foton.
    const perMapp = {};
    funna.forEach((f) => {
      const rad = perMapp[f.mapp] || (perMapp[f.mapp] = { w: 0, n: 0, sedda: {} });
      if (f.w > rad.w) rad.w = f.w;
      if (!rad.sedda[f.master]) { rad.sedda[f.master] = 1; rad.n++; }
    });
    let egenMapp = "", bastBredd = -1, bastAntal = -1;
    Object.keys(perMapp).forEach((k) => {
      const r = perMapp[k];
      if (r.w > bastBredd || (r.w === bastBredd && r.n > bastAntal)) {
        bastBredd = r.w; bastAntal = r.n; egenMapp = k;
      }
    });
    const seenV = {};
    const vo = [];
    funna.forEach((f) => {
      if (f.mapp !== egenMapp) return;            // grannannonsernas foton
      if (seenV[f.master]) return;
      seenV[f.master] = 1;
      const full = abs(f.host + "/2470x1710,fit,q95/" + f.master);
      if (full) vo.push(full);
    });
    if (vo.length) {
      picked.length = 0;
      vo.forEach((u) => picked.push({ url: u, id: idOf(u) }));
    }
  }

  // Sajtspecifika boosters (ger HELA galleriet aven nar det ar lazy-laddat).
  const add = (u) => { const id = idOf(u); if (!denyId[id] && !seenId[id]) { seenId[id] = 1; picked.unshift({ url: u, id: id }); } };
  let mm;
  if (/qasa/i.test(location.hostname)) {
    const reQasa = /\/img\/([a-f0-9]{16,})\.(jpe?g|png|webp)/gi;
    while ((mm = reQasa.exec(flat))) {
      add('https://img.qasa.se/unsafe/adaptive-fit-in/1200x1200/https://qasa-static-prod.s3-eu-west-1.amazonaws.com/img/' + (mm[1] + '.' + mm[2]).toLowerCase());
    }
  }
  // AIRBNB-GALLERI: sidan bar sin EGNA fotolista som "baseUrl"-poster (samma data som
  // "Visa alla foton"/Fotorundturen renderar). Den listan ar den enda sanningen: den saknar
  // grannannonser, vardavatar, kartor och ikoner. Verifierat pa /rooms/43473343: 29 foton,
  // och lika manga BADE fore och efter att galleriet oppnats - inget klick behovs.
  if (/airbnb/i.test(location.hostname)) {
    const KEY = String.fromCharCode(34) + "baseUrl" + String.fromCharCode(34) + ":" + String.fromCharCode(34);
    const QUOTE = String.fromCharCode(34);
    const gallery = [];
    const seenG = {};
    const raw = [];
    let at = 0;
    while (true) {
      const st = flat.indexOf(KEY, at);
      if (st < 0) break;
      const s2 = st + KEY.length;
      const en = flat.indexOf(QUOTE, s2);
      if (en < 0) break;
      at = en;
      const u = flat.slice(s2, en);
      if (u.indexOf("muscache") >= 0) raw.push(u);
    }
    // TVA URL-familjer, och de FOREKOMMER I SAMMA ANNONS. Nyare foton:
    // .../Hosting-<annons-id>/original/... - dar bar fotot annonsens id, och id-filtret fran
    // v0.2.6 stoppar grannannonsernas bilder. Aldre foton: .../im/pictures/<uuid>.jpg - utan
    // id nagonstans.
    //
    // Beslutet maste darfor tas PER URL. Forr fragade koden "finns nagot id i listan?" och
    // lat svaret galla alla: pa /rooms/37986438 rackte ETT foto med id for att de 19 id-losa
    // skulle kastas - importen fick med en enda bild. (Rapporterat 2026-09-07.)
    raw.forEach(function (u) {
      if (u.indexOf("Hosting-") >= 0) {
        // Bar fotot ett id maste det vara VART. Utan id i adressen kan vi inte matcha,
        // och slapper da igenom - listan ar trots allt annonsens egen fototur.
        if (roomId && !ownHosting(u)) return;
      } else {
        // Inget id att filtrera pa. Listan ar annonsens EGEN fototur - matt pa /rooms/44440191:
        // 24 foton i listan, och de enda muscache-bilder i sidkoden som INTE fanns dar var
        // 4 plattformsikoner + vardens avatar. Sila bort just de tva sorterna.
        // BARA /im/pictures/ (bildtjansten). Listan innehaller aven EN post pa /pictures/ utan
        // "im" som ser ut som ett 24:e foto - men nar jag oppnade den var det Airbnbs egen
        // TECKNADE illustration (en vard som halsar gaster valkomna), inte bostaden.
        // Kontrollerat pa /rooms/44440191 2026-08-31. Slapp alltsa inte in den formen.
        if (u.indexOf("/im/pictures/") < 0) return;
        if (u.indexOf("platform-assets") >= 0 || u.indexOf("PlatformAssets") >= 0) return;
        if (u.indexOf("/user/") >= 0) return;   // vardens avatar
      }
      const f = fullSize(u);
      if (!seenG[f]) { seenG[f] = 1; gallery.push(f); }
    });
    // Ersatt allt annat: pa Airbnb ar det BARA fotolistan som galler.
    if (gallery.length) {
      picked.length = 0;
      gallery.forEach((u) => picked.push({ url: u, id: idOf(u) }));
    }
  }

  // SISTA SVEPET: samma foto liggande i flera storleks-MAPPAR.
  // thebestrent serverar varje foto ur /images/<bucket>/251/<id>.webp, dar <bucket> ar
  // 1,2,3,4,5,8,10 - olika storlekar OCH olika beskarningar av samma bild (400x400 kvadrat,
  // 1920x1080 bred, 1310x875 hel). idOf() stryker bara siffermappar med 2-4 siffror, sa de
  // ENSIFFRIGA buckets foll utanfor: fyra av annonsens foton lag kvar en extra gang och
  // trettio foton blev trettiofyra (rapporterat 2026-09-14).
  // Nyckeln stads LED FOR LED i stallet for med regex. idOf() strular namligen pa
  // siffermappar som star direkt efter varandra: i /images/10/251/x.webp ater traffen "/10/"
  // upp snedstrecket som "/251/" behover, sa bara den forsta forsvinner. Just den kvarglomman
  // holl kvar tva kvadratiska beskarningar (500x500) i listan.
  // Sajter med egen booster halls utanfor: vuokraovi doper VARJE foto till ORIGINAL.jpeg och
  // skiljer dem at enbart pa mappnamn, sa dar vore en bredare nyckel direkt farlig.
  if (!egenBooster && picked.length > 1) {
    const nyckel = (u) => {
      const delar = idOf(u).split("/");
      const ut = [];
      for (let i = 0; i < delar.length; i++) {
        const s = delar[i];
        if (i < delar.length - 1 && s.length >= 1 && s.length <= 4
            && String(parseInt(s, 10)) === s) continue;
        ut.push(s);
      }
      return ut.join("/");
    };
    const sedd = {};
    const kvar = [];
    picked.forEach((p) => {
      const k = nyckel(p.url);
      const vid = sedd[k];
      if (vid === undefined) { sedd[k] = kvar.length; kvar.push(p); return; }
      // MINST EN av de tva maste ha kommit ur en lightbox-lank. Det ar den enda kvitto vi
      // har pa att sajten sjalv behandlar dem som samma foto i olika storlek. Utan det
      // kravet skulle /galleri/1/main.jpg och /galleri/2/main.jpg - som mycket val KAN vara
      // tva olika bilder pa en sajt vi aldrig sett - sla ihop och ett foto tappas bort.
      // Pa thebestrent bar galleriets variant (bucket 3) flaggan, sa fixen star kvar.
      if (!p.lank && !kvar[vid].lank) { kvar.push(p); return; }
      // Behall den som kom ur lightbox-lanken - det ar galleriets egen fullvy.
      if (p.lank && !kvar[vid].lank) kvar[vid] = p;
    });
    if (kvar.length) { picked.length = 0; kvar.forEach((p) => picked.push(p)); }
  }

  return { html: html, url: pageUrl, photos: picked.map((p) => p.url).slice(0, 100) };
}

// TOMT FORMULAR - vagen in nar man bara vill fylla i for hand med egna bilder, utan att lasa
// nagon annons. Nas pa tva satt: hogerklick pa ikonen, eller klick pa ikonen nar man inte
// star pa en vanlig webbsida (ny flik, chrome://, var egen granskningsflik). Forr gav det
// sista bara ett felmeddelande.
async function openBlankForm() {
  // Rensa ev. gammal skord sa den inte dyker upp i det "tomma" formularet.
  try { await chrome.storage.local.remove('handoff'); } catch (e) { /* strunt i det */ }
  await chrome.tabs.create({ url: chrome.runtime.getURL('review.html') + '?blank=1' });
}

function registerMenu() {
  if (!chrome.contextMenus) return;
  try {
    chrome.contextMenus.removeAll(() => {
      // Chrome MV3 kallar kontexten "action"; aldre Firefox-byggen kanner bara "browser_action".
      try {
        chrome.contextMenus.create({ id: 'nordicta-blank', title: 'Öppna tomt formulär (läs inte sidan)', contexts: ['action'] });
      } catch (e) {
        chrome.contextMenus.create({ id: 'nordicta-blank', title: 'Öppna tomt formulär (läs inte sidan)', contexts: ['browser_action'] });
      }
    });
  } catch (e) { /* menyn ar en genvag, inte ett krav - tillagget ska funka utan den */ }
}
chrome.runtime.onInstalled.addListener(registerMenu);
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(registerMenu);
if (chrome.contextMenus && chrome.contextMenus.onClicked) {
  chrome.contextMenus.onClicked.addListener((info) => {
    if (info && info.menuItemId === 'nordicta-blank') openBlankForm();
  });
}

chrome.action.onClicked.addListener(async (tab) => {
  const u = (tab && tab.url) || '';
  const isWeb = u.indexOf('http://') === 0 || u.indexOf('https://') === 0;
  // Tom URL = vi ser den inte (rattighetsfraga) - forsok skorda anda. Men vet vi att det
  // INTE ar en webbsida finns ingen annons att lasa: oppna formularet i stallet.
  if (!tab || !tab.id || (u && !isWeb)) return openBlankForm();
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: harvestPage });
    const data = (res && res.result) || {};
    await chrome.storage.local.set({ handoff: { html: data.html || '', url: data.url || '', photos: data.photos || [], ts: Date.now() } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('review.html') });
  } catch (e) {
    // activeTab isn't granted on restricted pages (chrome://, the Web Store, PDF viewer…).
    await chrome.storage.local.set({ handoff: { error: String(e && e.message || e), ts: Date.now() } });
    await chrome.tabs.create({ url: chrome.runtime.getURL('review.html') });
  }
});
