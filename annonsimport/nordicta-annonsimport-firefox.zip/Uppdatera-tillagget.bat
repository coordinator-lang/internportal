@echo off
REM Nordicta Annonsimport - dubbelklicka for att uppdatera tillagget.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update-extension.ps1"
