# Nordicta Annonsimport - uppdaterare
# ASCII ONLY: Windows PowerShell 5.1 laser .ps1 som ANSI, sa svenska tecken bryter parsningen.
#
# Hamtar senaste versionen av tillagget fran internportalen och packar upp den over
# den har mappen. Kor via "Uppdatera-tillagget.bat" (dubbelklick).

[CmdletBinding()]
param(
  [string]$Target  = $PSScriptRoot,
  [string]$BaseUrl = "https://coordinator-lang.github.io/internportal/annonsimport"
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Say($msg, $color = "Gray") { Write-Host $msg -ForegroundColor $color }

Say ""
Say "  Nordicta Annonsimport - uppdatering" "Cyan"
Say "  ----------------------------------" "Cyan"

$manifestPath = Join-Path $Target "manifest.json"
if (-not (Test-Path -LiteralPath $manifestPath)) {
  Say "  FEL: hittar ingen manifest.json i:" "Red"
  Say "  $Target" "Red"
  Say ""
  Say "  Lagg den har filen i SAMMA mapp som tillagget." "Yellow"
  Read-Host "  Tryck Enter for att stanga"; exit 1
}

$local = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$localVersion = $local.version
# Vilken variant ar installerad? Chrome anvander service_worker, Firefox scripts.
$isFirefox = $null -ne $local.background.scripts
$variant = if ($isFirefox) { "firefox" } else { "chrome" }
Say "  Installerad version : $localVersion ($variant)"

try {
  $info = Invoke-RestMethod -Uri "$BaseUrl/version.json" -UseBasicParsing -TimeoutSec 20
} catch {
  Say "  FEL: kunde inte kontakta internportalen." "Red"
  Say "  $($_.Exception.Message)" "DarkGray"
  Read-Host "  Tryck Enter for att stanga"; exit 1
}

$remoteVersion = $info.version
Say "  Senaste version     : $remoteVersion"
Say ""

if ([version]$remoteVersion -le [version]$localVersion) {
  Say "  Du har redan senaste versionen. Inget att gora." "Green"
  Read-Host "  Tryck Enter for att stanga"; exit 0
}

$zipName = if ($isFirefox) { $info.firefox } else { $info.chrome }
$zipUrl  = "$BaseUrl/$zipName"
Say "  Hamtar $zipName ..." "Yellow"

$tmp = Join-Path $env:TEMP ("nordicta-ext-" + (Get-Date -Format "yyyyMMddHHmmss"))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$zipPath = Join-Path $tmp "ext.zip"

try {
  Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
} catch {
  Say "  FEL: nedladdningen misslyckades." "Red"
  Say "  $($_.Exception.Message)" "DarkGray"
  Read-Host "  Tryck Enter for att stanga"; exit 1
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
$unpack = Join-Path $tmp "unpacked"
New-Item -ItemType Directory -Force -Path $unpack | Out-Null
[System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $unpack)

if (-not (Test-Path -LiteralPath (Join-Path $unpack "manifest.json"))) {
  Say "  FEL: paketet ser felaktigt ut (ingen manifest.json)." "Red"
  Read-Host "  Tryck Enter for att stanga"; exit 1
}

# Kopiera over filerna. Behall mappen sa Chrome/Firefox behaller sitt tilllaggs-ID.
Say "  Packar upp over mappen ..." "Yellow"
foreach ($item in (Get-ChildItem -LiteralPath $unpack -Force)) {
  Copy-Item -LiteralPath $item.FullName -Destination $Target -Recurse -Force
}

try { Remove-Item -LiteralPath $tmp -Recurse -Force } catch { }

Say ""
Say "  KLART - version $remoteVersion ar installerad." "Green"
Say ""
Say "  SISTA STEGET (en gang):" "Cyan"
if ($isFirefox) {
  Say "  Oppna about:debugging#/runtime/this-firefox och klicka 'Las in pa nytt'."
} else {
  Say "  Oppna chrome://extensions och klicka reload-ikonen pa Nordicta Annonsimport."
}
Say ""
Read-Host "  Tryck Enter for att stanga"
